# CSA03 - Data Structures - Assignment 5 (CO5)
**Modelling and Analysing Real-World Networks with Graphs - Chennai City Mobility and Delivery Network**

| | |
|---|---|
| Name | Gnana Priyan G |
| Register number | 192521393 |
| Department / year | IT, II year (2025 batch) |
| Faculty | Monoj D |
| Compiler | gcc 13.3.0 (Ubuntu 24.04) |
| Compile command | `gcc -std=c11 -Wall -Wextra <file>.c -o <name>` (`-g -fsanitize=address` for tests, `-O2` for timings, `-lm` where needed) |

## How to run
    ./run_all.sh        # compiles and runs everything, output goes to <folder>/outputs/
Single program: `cd B3 && gcc -std=c11 -Wall -Wextra -O2 b3_compare.c -o b3_compare && ./b3_compare scale`

## Tasks and results (measured on my run)
| Folder | Programs | Result |
|---|---|---|
| A2 | `a2_predict.c`, `a2_trace.c`, `a2_depth.c` | DFS `0 1 3 5 4 2`, BFS `0 1 2 3 4 5`; recursive DFS on a chain of 1,000,000 junctions crashes (exit 139), the explicit-stack version completes |
| A3 | `a3_kahn.c`, `a3_dfs_topo.c` | `Lease Power Racks Staff Network Launch`, valid schedule; with edge Launch -> Lease: cycle detected (both algorithms) |
| A4 | `a4_predict.c`, `a4_hubs.c` | Floyd-Warshall matrix traced; row 0 column 3 changes 10 -> 9; Floyd vs Dijkstra from every hub give identical tables |
| A5 | `a5_prim.c`, `a5_kruskal.c` | `0-1(2) 1-2(3) 0-3(6) 1-4(5)`, total 16; Kruskal gives the same total |
| B1 | `b1_bfs_complete.c`, `b1_traversals.c` | Koyambedu is 3 stops away; flood splits 12 junctions into 3 regions; matrix BFS at 50,000 vertices 1,795 ms and 2.5 GB vs list 1.4 ms and 1.1 MB |
| B2 | `b2_dijkstra_complete.c`, `b2_difficult.c` | `0 7 9 20 20 11`; unreachable, negative edge, overflow and cycle tests |
| B3 | `b3_compare.c`, `b3_astar.c` | all three algorithms agree; 10,000 vertices: array Dijkstra about 92 ms per source, heap about 0.7 ms per source; A* explores 21-30% of Dijkstra's vertices |
| B4 | `b4_prim_hubs.c`, B3 `big` mode | 20-hub cable plan 599 lakh (601 after one route is removed); 250,000 junctions: 40 ms per source, 9.7 MB |

## Notes
* Screenshots are terminal-style images rendered from the real output of these programs; replace with your own captures if required.
* Timings depend on the machine. The Floyd-Warshall time for 10,000 vertices is estimated from the 1,000-vertex run (x1000), as the task allows.
* Commit each task separately as you finish it (the commit history is checked).
* The full report (Word file) is in report/

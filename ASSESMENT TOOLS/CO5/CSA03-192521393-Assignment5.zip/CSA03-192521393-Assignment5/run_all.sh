#!/bin/bash
# Compiles and runs every program of Assignment 5 (takes about 1 minute). Output goes to <folder>/outputs/
set -e
G="-std=c11 -Wall -Wextra"; ASAN="-g -fsanitize=address"
run() { d=$1; s=$2; f=$3; shift 3; echo "== $d/$s $*"; (cd $d && gcc $G $f $s.c -o $s.bin -lm && ./$s.bin "$@" | tee outputs/$s${SUFFIX}.txt; rm -f $s.bin); }
run A2 a2_predict "$ASAN"; run A2 a2_trace "$ASAN"
run A2 a2_depth "-O2" 50000 r; SUFFIX=_stack run A2 a2_depth "-O2" 1000000 s
echo "(a2_depth 1000000 r crashes with a segmentation fault: that is the expected result of the recursive version)"
run A3 a3_kahn "$ASAN"; SUFFIX=_cycle run A3 a3_kahn "$ASAN" x; run A3 a3_dfs_topo "$ASAN"
run A4 a4_predict "$ASAN"; run A4 a4_hubs "-O2"
run A5 a5_prim "$ASAN"; run A5 a5_kruskal "-O2"
run B1 b1_bfs_complete "$ASAN"; run B1 b1_traversals "$ASAN"
for v in 1000 10000 50000; do SUFFIX=_scale_$v run B1 b1_traversals "-O2" scale $v; done
run B2 b2_dijkstra_complete "$ASAN"; run B2 b2_difficult "$ASAN"
SUFFIX=_small run B3 b3_compare "$ASAN" small; SUFFIX=_scale run B3 b3_compare "-O2" scale; SUFFIX=_big run B3 b3_compare "-O2" big
run B3 b3_astar "-O2"; run B4 b4_prim_hubs "$ASAN"

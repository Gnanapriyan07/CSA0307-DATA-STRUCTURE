/* B1: BFS/DFS on an adjacency list, components after flooding, cycle detection, matrix vs list.
   usage: b1_traversals            (validation, components, cycles)
          b1_traversals scale V    (matrix versus list BFS for V vertices) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef struct { int V, *start, *adj; } G;           /* CSR adjacency list */
static G build(int V, int (*e)[2], const char *removed, int m) {
    G g; g.V = V; g.start = calloc((size_t)V + 2, sizeof(int)); int cnt = 0;
    for (int i = 0; i < m; i++) if (!removed || !removed[i]) { g.start[e[i][0] + 1]++; g.start[e[i][1] + 1]++; cnt += 2; }
    for (int v = 0; v < V; v++) g.start[v + 1] += g.start[v];
    g.adj = malloc((size_t)cnt * sizeof(int)); int *pos = malloc((size_t)V * sizeof(int)); memcpy(pos, g.start, (size_t)V * sizeof(int));
    for (int i = 0; i < m; i++) if (!removed || !removed[i]) { g.adj[pos[e[i][0]]++] = e[i][1]; g.adj[pos[e[i][1]]++] = e[i][0]; }
    free(pos); return g;
}
static void freeg(G *g) { free(g->start); free(g->adj); }
static int components(const G *g, int *comp) {
    int V = g->V, *q = malloc((size_t)V * sizeof(int)), nc = 0;
    for (int v = 0; v < V; v++) comp[v] = -1;
    for (int s = 0; s < V; s++) if (comp[s] < 0) {
        int h = 0, t = 0; q[t++] = s; comp[s] = nc;
        while (h < t) { int u = q[h++]; for (int i = g->start[u]; i < g->start[u + 1]; i++) { int w = g->adj[i]; if (comp[w] < 0) { comp[w] = nc; q[t++] = w; } } }
        nc++; }
    free(q); return nc;
}
static int has_cycle_dfs(const G *g, int u, int parent, char *seen) {   /* undirected graph */
    seen[u] = 1;
    for (int i = g->start[u]; i < g->start[u + 1]; i++) { int w = g->adj[i];
        if (!seen[w]) { if (has_cycle_dfs(g, w, u, seen)) return 1; } else if (w != parent) return 1; }
    return 0;
}
static int has_cycle(const G *g) { char *seen = calloc((size_t)g->V, 1); int r = 0; for (int v = 0; v < g->V && !r; v++) if (!seen[v]) r = has_cycle_dfs(g, v, -1, seen); free(seen); return r; }
static double ms(clock_t a) { return (double)(clock() - a) * 1000.0 / CLOCKS_PER_SEC; }
static void scale(int V) {
    int m = (int)(2.4 * V); int (*e)[2] = malloc((size_t)m * sizeof *e); srand(17);
    for (int i = 0; i < m; i++) { e[i][0] = rand() % V; e[i][1] = rand() % V; }
    G g = build(V, e, NULL, m);
    size_t list_bytes = (size_t)(V + 2) * sizeof(int) + (size_t)g.start[V] * sizeof(int);
    int *dist = malloc((size_t)V * sizeof(int)), *q = malloc((size_t)V * sizeof(int));
    clock_t t0 = clock(); long reach_l = 0;
    for (int rep = 0; rep < 5; rep++) { for (int v = 0; v < V; v++) dist[v] = -1; int h = 0, t = 0; q[t++] = 0; dist[0] = 0;
        while (h < t) { int u = q[h++]; for (int i = g.start[u]; i < g.start[u + 1]; i++) { int w = g.adj[i]; if (dist[w] < 0) { dist[w] = dist[u] + 1; q[t++] = w; } } } reach_l = t; }
    double t_list = ms(t0) / 5;
    size_t mat_bytes = (size_t)V * V;                    /* 1 byte per cell */
    unsigned char *mat = calloc(mat_bytes, 1);
    if (!mat) { printf("V=%-6d list: %zu bytes, %.2f ms | matrix: %zu bytes could not be allocated\n", V, list_bytes, t_list, mat_bytes); return; }
    for (int i = 0; i < m; i++) { mat[(size_t)e[i][0] * V + e[i][1]] = 1; mat[(size_t)e[i][1] * V + e[i][0]] = 1; }
    t0 = clock(); long reach_m = 0;
    for (int v = 0; v < V; v++) dist[v] = -1;
    { int h = 0, t = 0; q[t++] = 0; dist[0] = 0;
      while (h < t) { int u = q[h++]; const unsigned char *row = mat + (size_t)u * V; for (int w = 0; w < V; w++) if (row[w] && dist[w] < 0) { dist[w] = dist[u] + 1; q[t++] = w; } } reach_m = t; }
    double t_mat = ms(t0);
    free(mat); free(dist); free(q); free(e); freeg(&g);
    printf("V=%-6d E=%-7d | list: %9zu bytes, BFS %8.3f ms | matrix: %12zu bytes, BFS %9.3f ms | reached %ld/%ld %s\n",
           V, m, list_bytes, t_list, mat_bytes, t_mat, reach_l, reach_m, reach_l == reach_m ? "(same)" : "(DIFFERENT)");
}
int main(int argc, char **argv) {
    if (argc > 2 && strcmp(argv[1], "scale") == 0) { scale(atoi(argv[2])); return 0; }
    /* metro: verify fewest stops by hand: Airport-Guindy-Vadapalani-Koyambedu = 3 */
    int me[8][2] = {{0,1},{1,2},{2,3},{3,4},{1,5},{5,6},{4,6},{0,0}}; int mm = 7;
    G metro = build(7, me, NULL, mm); int comp[64];
    printf("metro: %d line segments, connected regions = %d\n", mm, components(&metro, comp));
    /* road network after a flood: 12 junctions, 14 roads, flooded roads are removed */
    int re[14][2] = {{0,1},{1,2},{2,3},{3,4},{4,5},{5,0},{6,7},{7,8},{8,9},{9,6},{10,11},{2,6},{3,8},{5,10}};
    char flooded[14] = {0};
    G roads = build(12, re, flooded, 14);
    printf("roads (12 junctions, 14 roads): regions = %d, cycle = %s\n", components(&roads, comp), has_cycle(&roads) ? "yes" : "no");
    flooded[11] = flooded[12] = flooded[13] = 1;         /* roads 2-6, 3-8 and 5-10 closed */
    G wet = build(12, re, flooded, 14);
    int nc = components(&wet, comp);
    printf("after flooding roads 2-6, 3-8, 5-10: regions = %d, junction -> region:", nc);
    for (int v = 0; v < 12; v++) printf(" %d:%d", v, comp[v]);
    printf("\n");
    int tre[5][2] = {{0,1},{1,2},{2,3},{3,4},{1,4}};     /* has the cycle 1-2-3-4-1 */
    int tre2[4][2] = {{0,1},{1,2},{2,3},{3,4}};          /* a path: no cycle */
    G cyc = build(5, tre, NULL, 5), tree = build(5, tre2, NULL, 4);
    printf("cycle test: graph with edge 1-4: %s; path graph: %s\n", has_cycle(&cyc) ? "cycle found" : "no cycle", has_cycle(&tree) ? "cycle found" : "no cycle");
    freeg(&metro); freeg(&roads); freeg(&wet); freeg(&cyc); freeg(&tree);
    return 0;
}

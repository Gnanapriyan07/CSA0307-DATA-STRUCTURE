/* B3.3: A* (Manhattan heuristic) versus Dijkstra on a 4-connected grid, unit cost per step */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define N 500
typedef struct { int f, g, v; } Nd;
static char blocked[N][N];
static int dist_[N * N], closed_[N * N];
static Nd *heap; static int hn;
static void push(Nd x) { int i = hn++; heap[i] = x; while (i > 0 && heap[(i-1)/2].f > heap[i].f) { Nd t = heap[i]; heap[i] = heap[(i-1)/2]; heap[(i-1)/2] = t; i = (i-1)/2; } }
static Nd pop(void) { Nd top = heap[0]; heap[0] = heap[--hn]; int i = 0;
    for (;;) { int l = 2*i+1, r = l+1, b = i; if (l < hn && heap[l].f < heap[b].f) b = l; if (r < hn && heap[r].f < heap[b].f) b = r; if (b == i) break; Nd t = heap[i]; heap[i] = heap[b]; heap[b] = t; i = b; }
    return top; }
static int h(int v, int goal) { return abs(v / N - goal / N) + abs(v % N - goal % N); }
/* returns path length (or -1); *explored = vertices removed from the queue and expanded */
static int search(int start, int goal, int use_h, long *explored) {
    for (int i = 0; i < N * N; i++) { dist_[i] = 1 << 30; closed_[i] = 0; }
    hn = 0; *explored = 0; dist_[start] = 0; push((Nd){use_h ? h(start, goal) : 0, 0, start});
    int dr[4] = {1, -1, 0, 0}, dc[4] = {0, 0, 1, -1};
    while (hn) {
        Nd x = pop(); if (closed_[x.v]) continue; closed_[x.v] = 1; (*explored)++;
        if (x.v == goal) return x.g;
        for (int k = 0; k < 4; k++) { int r = x.v / N + dr[k], c = x.v % N + dc[k]; if (r < 0 || c < 0 || r >= N || c >= N || blocked[r][c]) continue;
            int w = r * N + c, ng = x.g + 1; if (ng < dist_[w]) { dist_[w] = ng; push((Nd){ng + (use_h ? h(w, goal) : 0), ng, w}); } }
    }
    return -1;
}
static void run(const char *name, int start, int goal) {
    long ed, ea; clock_t t0 = clock(); int ld = search(start, goal, 0, &ed); double td = (double)(clock() - t0) * 1000 / CLOCKS_PER_SEC;
    t0 = clock(); int la = search(start, goal, 1, &ea); double ta = (double)(clock() - t0) * 1000 / CLOCKS_PER_SEC;
    printf("%-28s path length: Dijkstra %d, A* %d %s | explored: Dijkstra %6ld, A* %6ld (%.1f%%) | time: %.2f ms vs %.2f ms\n",
           name, ld, la, ld == la ? "(equal)" : "(DIFFERENT)", ed, ea, 100.0 * ea / ed, td, ta);
}
int main(void) {
    heap = malloc((size_t)N * N * 8 * sizeof *heap);
    int start = 0, goal = N * N - 1;
    memset(blocked, 0, sizeof blocked);
    run("open map (no obstacles)", start, goal);
    for (int seed = 12;; seed++) {                           /* pick the first seed whose map is solvable */
        srand((unsigned)seed);
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) blocked[r][c] = rand() % 100 < 25;
        blocked[0][0] = blocked[N-1][N-1] = 0;
        long tmp; if (search(start, goal, 0, &tmp) >= 0) { printf("(random map: seed %d)\n", seed); break; }
    }
    run("25% random obstacles", start, goal);
    memset(blocked, 0, sizeof blocked);                      /* a wall with a gap at the far end: A* is misled */
    for (int c = 0; c < N - 1; c++) blocked[N / 2][c] = 1;
    run("long wall, gap at far side", start, goal);
    for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) blocked[r][c] = 0;
    for (int r = 0; r < N; r++) blocked[r][N / 2] = 1;
    run("goal unreachable (full wall)", start, goal);
    free(heap); return 0;
}

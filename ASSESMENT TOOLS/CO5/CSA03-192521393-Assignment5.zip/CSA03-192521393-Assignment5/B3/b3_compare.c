/* B3: Dijkstra (array), Dijkstra (binary heap) and Floyd-Warshall.   usage: b3_compare small | scale | big */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#define INF 1000000000
typedef struct { int V, *start, *to, *wt; } G;
static G make(int V, int per, unsigned seed) {            /* ring (keeps it connected) + (per-1) random edges per vertex */
    G g; g.V = V; int m = V * per; g.start = malloc((size_t)(V + 1) * sizeof(int)); g.to = malloc((size_t)m * sizeof(int)); g.wt = malloc((size_t)m * sizeof(int));
    srand(seed); int k = 0;
    for (int u = 0; u < V; u++) { g.start[u] = k; g.to[k] = (u + 1) % V; g.wt[k++] = 1 + rand() % 100;
        for (int j = 1; j < per; j++) { g.to[k] = rand() % V; g.wt[k++] = 1 + rand() % 100; } }
    g.start[V] = k; return g;
}
static void freeg(G *g) { free(g->start); free(g->to); free(g->wt); }
static void dij_array(const G *g, int s, int *dist) {
    int V = g->V; char *done = calloc((size_t)V, 1);
    for (int v = 0; v < V; v++) dist[v] = INF;
    dist[s] = 0;
    for (int r = 0; r < V; r++) {
        int u = -1; for (int v = 0; v < V; v++) if (!done[v] && dist[v] != INF && (u < 0 || dist[v] < dist[u])) u = v;
        if (u < 0) break;
        done[u] = 1;
        for (int i = g->start[u]; i < g->start[u + 1]; i++) { int v = g->to[i]; if (!done[v] && dist[u] + g->wt[i] < dist[v]) dist[v] = dist[u] + g->wt[i]; }
    }
    free(done);
}
typedef struct { int d, v; } HN;
static void dij_heap(const G *g, int s, int *dist) {
    int V = g->V, m = g->start[V], cap = m + 2; HN *h = malloc((size_t)cap * sizeof *h); int n = 0;
    for (int v = 0; v < V; v++) dist[v] = INF;
    dist[s] = 0; h[n++] = (HN){0, s};
    while (n) {
        HN top = h[0]; h[0] = h[--n];
        for (int i = 0;;) { int l = 2*i+1, r = l+1, b = i; if (l < n && h[l].d < h[b].d) b = l; if (r < n && h[r].d < h[b].d) b = r; if (b == i) break; HN t = h[i]; h[i] = h[b]; h[b] = t; i = b; }
        if (top.d > dist[top.v]) continue;                       /* stale entry */
        for (int i = g->start[top.v]; i < g->start[top.v + 1]; i++) { int v = g->to[i], nd = top.d + g->wt[i];
            if (nd < dist[v]) { dist[v] = nd; int j = n++; h[j] = (HN){nd, v};
                while (j > 0 && h[(j-1)/2].d > h[j].d) { HN t = h[j]; h[j] = h[(j-1)/2]; h[(j-1)/2] = t; j = (j-1)/2; } } }
    }
    free(h);
}
static int *floyd(const G *g) {
    int V = g->V; int *d = malloc((size_t)V * V * sizeof *d);
    for (size_t i = 0; i < (size_t)V * V; i++) d[i] = INF;
    for (int u = 0; u < V; u++) { d[(size_t)u*V+u] = 0; for (int i = g->start[u]; i < g->start[u+1]; i++) { int v = g->to[i]; if (g->wt[i] < d[(size_t)u*V+v]) d[(size_t)u*V+v] = g->wt[i]; } }
    for (int k = 0; k < V; k++) for (int i = 0; i < V; i++) { int dik = d[(size_t)i*V+k]; if (dik == INF) continue;
        for (int j = 0; j < V; j++) { int dkj = d[(size_t)k*V+j]; if (dkj != INF && dik + dkj < d[(size_t)i*V+j]) d[(size_t)i*V+j] = dik + dkj; } }
    return d;
}
static double ms(clock_t a) { return (double)(clock() - a) * 1000.0 / CLOCKS_PER_SEC; }
int main(int argc, char **argv) {
    const char *mode = argc > 1 ? argv[1] : "small";
    if (!strcmp(mode, "small")) {
        G g = make(8, 3, 5); int *fw = floyd(&g), a[8], b[8], ok = 1;
        printf("8 vertices, %d directed roads. Distances from vertex 0 and all-pairs check:\n", g.start[8]);
        dij_array(&g, 0, a); dij_heap(&g, 0, b);
        printf("  array : "); for (int v = 0; v < 8; v++) printf("%4d", a[v]); printf("\n  heap  : "); for (int v = 0; v < 8; v++) printf("%4d", b[v]);
        printf("\n  Floyd : "); for (int v = 0; v < 8; v++) printf("%4d", fw[v]); printf("\n");
        for (int s = 0; s < 8; s++) { dij_array(&g, s, a); dij_heap(&g, s, b); for (int v = 0; v < 8; v++) if (a[v] != b[v] || a[v] != fw[s*8+v]) ok = 0; }
        printf("  all 64 pairs identical in the three algorithms: %s\n", ok ? "YES" : "NO");
        free(fw); freeg(&g);
        G h = make(200, 3, 9); int *fw2 = floyd(&h), aa[200], bb[200], ok2 = 1;
        for (int s = 0; s < 200; s++) { dij_array(&h, s, aa); dij_heap(&h, s, bb); for (int v = 0; v < 200; v++) if (aa[v] != bb[v] || aa[v] != fw2[s*200+v]) ok2 = 0; }
        printf("  200 vertices, all 40,000 pairs identical: %s\n", ok2 ? "YES" : "NO");
        free(fw2); freeg(&h);
    } else if (!strcmp(mode, "scale")) {
        printf("%-7s %-8s %-16s %-16s %-18s\n", "V", "E", "Dijkstra array", "Dijkstra heap", "Floyd-Warshall");
        double tf_prev = 0; int vprev = 0;
        int sizes[] = {100, 1000, 10000};
        for (int si = 0; si < 3; si++) {
            int V = sizes[si]; G g = make(V, 3, 21); int *d = malloc((size_t)V * sizeof(int)); int reps = V <= 1000 ? 20 : 3, srcs = 10;
            clock_t t0 = clock(); for (int r = 0; r < reps; r++) for (int s = 0; s < srcs; s++) dij_array(&g, s * (V / 10), d);
            double ta = ms(t0) / (reps * srcs);
            t0 = clock(); for (int r = 0; r < reps * 5; r++) for (int s = 0; s < srcs; s++) dij_heap(&g, s * (V / 10), d);
            double th = ms(t0) / (reps * 5 * srcs);
            char fwbuf[64];
            if (V <= 1000) { t0 = clock(); int *f = floyd(&g); double tf = ms(t0); free(f); snprintf(fwbuf, sizeof fwbuf, "%.2f ms (all pairs)", tf); tf_prev = tf; vprev = V; }
            else { double est = tf_prev * (double)V * V * V / ((double)vprev * vprev * vprev); snprintf(fwbuf, sizeof fwbuf, "~%.0f s est. (x%.0f)", est / 1000, (double)V * V * V / ((double)vprev * vprev * vprev)); }
            printf("%-7d %-8d %-9.4f ms/src  %-9.4f ms/src  %-18s\n", V, g.start[V], ta, th, fwbuf);
            free(d); freeg(&g);
        }
    } else {
        int V = 250000; G g = make(V, 3, 33); int *d = malloc((size_t)V * sizeof(int));
        clock_t t0 = clock(); for (int r = 0; r < 5; r++) dij_heap(&g, r * 1000, d);
        double th = ms(t0) / 5; struct rusage ru; getrusage(RUSAGE_SELF, &ru);
        size_t graph_bytes = (size_t)(V + 1) * 4 + (size_t)g.start[V] * 8, work = (size_t)V * 4 + ((size_t)g.start[V] + 2) * 8;
        printf("V=%d E=%d: heap Dijkstra %.1f ms per source; graph arrays %.1f MB, working memory %.1f MB; peak resident size %.1f MB\n",
               V, g.start[V], th, graph_bytes / 1048576.0, work / 1048576.0, ru.ru_maxrss / 1024.0);
        printf("array Dijkstra at V=250,000 is O(V^2) = 6.25e10 steps: not run (about 625 times the 10,000-vertex time)\n");
        free(d); freeg(&g);
    }
    return 0;
}

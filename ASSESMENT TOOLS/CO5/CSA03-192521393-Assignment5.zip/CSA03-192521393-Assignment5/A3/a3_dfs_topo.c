/* Topological order by DFS finishing time, with cycle detection by colours (0 white, 1 grey, 2 black) */
#include <stdio.h>
#define V 6
const char *task[V] = {"Lease", "Power", "Racks", "Network", "Staff", "Launch"};
int g[V][V] = {{0,1,1,0,1,0},{0,0,0,1,0,0},{0,0,0,1,0,0},{0,0,0,0,0,1},{0,0,0,0,0,1},{0,0,0,0,0,0}};
int color[V], order[V], n = 0, cyc = 0;
static void dfs(int u) {
    color[u] = 1;
    for (int v = 0; v < V; v++) if (g[u][v]) { if (color[v] == 1) cyc = 1; else if (color[v] == 0) dfs(v); }
    color[u] = 2; order[n++] = u;                     /* finished: goes to the FRONT of the list */
}
int main(int argc, char **argv) {
    (void)argv;
 if (argc > 1) g[5][0] = 1;
    for (int u = 0; u < V; u++) if (!color[u]) dfs(u);
    if (cyc) { printf("cycle detected (a grey vertex was reached again)\n"); return 0; }
    for (int i = n - 1; i >= 0; i--) printf("%s ", task[order[i]]);
    printf("\nvalid schedule\n");
    return 0;
}

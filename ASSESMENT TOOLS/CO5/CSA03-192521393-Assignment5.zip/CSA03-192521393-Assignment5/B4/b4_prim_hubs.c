/* B4.1: Prim's algorithm for 20 new hubs, and the plan when one cable route becomes unavailable */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define H 20
static int x[H], y[H], cost[H][H];      /* cost in Rs lakh = distance in km x 2 (rounded); 0 = not possible */
static int plan(int banned_a, int banned_b, int print, int *pa, int *pb, int *pc) {
    int key[H], parent[H], in[H] = {0}, total = 0;
    for (int v = 0; v < H; v++) { key[v] = 1 << 30; parent[v] = -1; }
    key[0] = 0;
    for (int k = 0; k < H; k++) {
        int u = -1; for (int v = 0; v < H; v++) if (!in[v] && (u < 0 || key[v] < key[u])) u = v;
        if (key[u] == (1 << 30)) { if (print) printf("network cannot be connected\n"); return -1; }
        in[u] = 1; total += key[u];
        for (int v = 0; v < H; v++) {
            if (in[v] || cost[u][v] <= 0) continue;
            if ((u == banned_a && v == banned_b) || (u == banned_b && v == banned_a)) continue;       /* route unavailable */
            if (cost[u][v] < key[v]) { key[v] = cost[u][v]; parent[v] = u; }
        }
    }
    for (int v = 1; v < H; v++) { if (print) printf("  H%02d-H%02d (%d)%s", parent[v] + 1, v + 1, cost[parent[v]][v], v % 4 == 0 ? "\n" : ""); if (pa) { pa[v] = parent[v]; pb[v] = v; pc[v] = cost[parent[v]][v]; } }
    if (print) printf("\n  total cost = %d lakh\n", total);
    return total;
}
int main(void) {
    srand(2026);
    for (int i = 0; i < H; i++) { x[i] = rand() % 100; y[i] = rand() % 100; }
    for (int i = 0; i < H; i++) for (int j = 0; j < H; j++) cost[i][j] = i == j ? 0 : (int)lround(2.0 * hypot(x[i] - x[j], y[i] - y[j]));
    int pa[H], pb[H], pc[H];
    printf("Cable plan connecting %d hubs (Prim):\n", H);
    int t0 = plan(-1, -1, 1, pa, pb, pc);
    int big = 1; for (int v = 2; v < H; v++) if (pc[v] > pc[big]) big = v;            /* cable that carries the most expensive link */
    printf("\nThe link H%02d-H%02d (cost %d) becomes unavailable (road works). New plan:\n", pa[big] + 1, pb[big] + 1, pc[big]);
    int t1 = plan(pa[big], pb[big], 1, NULL, NULL, NULL);
    printf("\nChange in total cost: %d -> %d lakh (+%d). Only the cables around the removed link change.\n", t0, t1, t1 - t0);
    return 0;
}

/* A2.3: BFS and DFS traced on the 7-station metro graph, plus DFS with an explicit stack */
#include <stdio.h>
#define V 7
const char *name[V] = {"Airport","Guindy","Saidapet","Central","Egmore","Vadapalani","Koyambedu"};
int start[V + 1] = {0, 1, 4, 6, 8, 10, 12, 14};
int adj[14] = {1, 0, 2, 5, 1, 3, 2, 4, 3, 6, 1, 6, 4, 5};
static void show(const char *label, int *a, int from, int to) { printf("%s[", label); for (int i = from; i < to; i++) printf("%s%d", i > from ? " " : "", a[i]); printf("]"); }
int main(void) {
    int q[V], h = 0, t = 0, seen[V] = {0};
    printf("BFS from 0 (queue shown after each removal):\n");
    q[t++] = 0; seen[0] = 1;
    while (h < t) {
        int u = q[h++];
        for (int i = start[u]; i < start[u + 1]; i++) { int w = adj[i]; if (!seen[w]) { seen[w] = 1; q[t++] = w; } }
        printf("  remove %d (%s)  ", u, name[u]); show("queue=", q, h, t); printf("\n");
    }
    printf("DFS from 0 with an explicit stack (stack shown after each pop):\n");
    int st[64], sp = 0, vis[V] = {0}; st[sp++] = 0;
    while (sp) {
        int u = st[--sp];
        if (vis[u]) continue;
        vis[u] = 1;
        for (int i = start[u + 1] - 1; i >= start[u]; i--) if (!vis[adj[i]]) st[sp++] = adj[i];   /* reversed so the lowest neighbour is visited first */
        printf("  visit %d (%s)  ", u, name[u]); show("stack=", st, 0, sp); printf("\n");
    }
    return 0;
}

#include <stdio.h>
#define V 6
int g[V][V] = {
 {0, 1, 1, 0, 0, 0},
 {1, 0, 0, 1, 1, 0},
 {1, 0, 0, 0, 1, 0},
 {0, 1, 0, 0, 0, 1},
 {0, 1, 1, 0, 0, 1},
 {0, 0, 0, 1, 1, 0},
};
int seen[V];
void dfs(int u)
{
 seen[u] = 1;
 printf("%d ", u);
 for (int v = 0; v < V; v++)
 if (g[u][v] && !seen[v]) dfs(v);
}
int main(void)
{
 dfs(0);
 printf("\n");
 /* BFS on the same graph (my prediction: 0 1 2 3 4 5) */
 int q[V], h = 0, t = 0, s2[V] = {0};
 q[t++] = 0; s2[0] = 1;
 while (h < t) { int u = q[h++]; printf("%d ", u);
   for (int v = 0; v < V; v++) if (g[u][v] && !s2[v]) { s2[v] = 1; q[t++] = v; } }
 printf("\n");
 return 0;
}

/* Recursive DFS vs explicit-stack DFS on a chain of N junctions. usage: a2_depth N r|s */
#include <stdio.h>
#include <stdlib.h>
static int *start, *adj, *seen, n;
static long visited = 0;
static void dfs_rec(int u) { seen[u] = 1; visited++; for (int i = start[u]; i < start[u + 1]; i++) if (!seen[adj[i]]) dfs_rec(adj[i]); }
static void dfs_stack(int s) {
    int *st = malloc((size_t)(n + 1) * sizeof *st), sp = 0; st[sp++] = s;
    while (sp) { int u = st[--sp]; if (seen[u]) continue; seen[u] = 1; visited++;
        for (int i = start[u]; i < start[u + 1]; i++) if (!seen[adj[i]]) st[sp++] = adj[i]; }
    free(st);
}
int main(int argc, char **argv) {
    n = argc > 1 ? atoi(argv[1]) : 50000; char mode = argc > 2 ? argv[2][0] : 'r';
    start = malloc((size_t)(n + 1) * sizeof *start); adj = malloc((size_t)n * sizeof *adj); seen = calloc((size_t)n, sizeof *seen);
    int e = 0; for (int u = 0; u < n; u++) { start[u] = e; if (u + 1 < n) adj[e++] = u + 1; } start[n] = e;   /* directed chain 0 -> 1 -> ... */
    if (mode == 'r') dfs_rec(0); else dfs_stack(0);
    printf("%s DFS on a chain of %d junctions: visited %ld\n", mode == 'r' ? "recursive" : "explicit-stack", n, visited);
    return 0;
}

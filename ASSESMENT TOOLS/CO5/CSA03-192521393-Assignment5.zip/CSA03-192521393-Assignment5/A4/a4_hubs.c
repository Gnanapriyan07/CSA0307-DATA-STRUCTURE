/* A4 alternative: hub-to-hub table, Floyd-Warshall vs Dijkstra from every hub, measured */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define INF 1000000000
#define REPS (V <= 100 ? 20 : 1)
static double secs(clock_t a) { return (double)(clock() - a) / CLOCKS_PER_SEC; }
int main(void) {
    int sizes[] = {30, 100, 300, 600};
    for (int si = 0; si < 4; si++) {
        int V = sizes[si];
        int *w = malloc((size_t)V * V * sizeof *w), *f = malloc((size_t)V * V * sizeof *f), *dd = malloc((size_t)V * V * sizeof *dd);
        srand(4);
        for (int i = 0; i < V; i++) for (int j = 0; j < V; j++) w[i*V+j] = i == j ? 0 : (rand() % 100 < 90 ? INF : 1 + rand() % 50);
        for (int i = 0; i + 1 < V; i++) { w[i*V+i+1] = 1 + rand() % 50; w[(i+1)*V+i] = 1 + rand() % 50; }
        clock_t t0 = clock();
        for (int r = 0; r < REPS; r++) { for (int i = 0; i < V*V; i++) f[i] = w[i];
            for (int k = 0; k < V; k++) for (int i = 0; i < V; i++) { int dik = f[i*V+k]; if (dik == INF) continue;
                for (int j = 0; j < V; j++) { int dkj = f[k*V+j]; if (dkj != INF && dik + dkj < f[i*V+j]) f[i*V+j] = dik + dkj; } } }
        double tf = secs(t0) / REPS;
        t0 = clock();
        for (int r = 0; r < REPS; r++)
            for (int s = 0; s < V; s++) {                       /* array Dijkstra from every hub */
                int *d = &dd[s*V]; char *done = calloc(V, 1);
                for (int i = 0; i < V; i++) d[i] = INF;
                d[s] = 0;
                for (int rd = 0; rd < V; rd++) { int u = -1;
                    for (int v = 0; v < V; v++) if (!done[v] && d[v] != INF && (u < 0 || d[v] < d[u])) u = v;
                    if (u < 0) break;
                    done[u] = 1;
                    for (int v = 0; v < V; v++) if (w[u*V+v] != INF && !done[v] && d[u] + w[u*V+v] < d[v]) d[v] = d[u] + w[u*V+v]; }
                free(done); }
        double td = secs(t0) / REPS; int same = 1;
        for (int i = 0; i < V*V; i++) if (f[i] != dd[i]) same = 0;
        printf("V=%-4d Floyd-Warshall %.5f s   Dijkstra from every vertex %.5f s   same table: %s\n", V, tf, td, same ? "yes" : "NO");
        free(w); free(f); free(dd);
    }
    return 0;
}

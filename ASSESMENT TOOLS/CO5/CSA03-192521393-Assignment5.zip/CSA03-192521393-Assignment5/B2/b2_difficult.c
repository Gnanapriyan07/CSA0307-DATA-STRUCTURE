/* B2: deliberately difficult inputs for Dijkstra, Floyd-Warshall, Bellman-Ford and topological sort */
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#define INF INT_MAX

/* ---- Dijkstra on a weight matrix (0 = no road), safe version: never adds to INF ---- */
static void dijkstra(int n, int w[][8], int src, int dist[]) {
    int done[8] = {0};
    for (int v = 0; v < n; v++) dist[v] = INF;
    dist[src] = 0;
    for (int r = 0; r < n; r++) {
        int u = -1;
        for (int v = 0; v < n; v++) if (!done[v] && dist[v] != INF && (u == -1 || dist[v] < dist[u])) u = v;
        if (u == -1) break;
        done[u] = 1;
        for (int v = 0; v < n; v++) if (w[u][v] != 0 && !done[v] && dist[u] + w[u][v] < dist[v]) dist[v] = dist[u] + w[u][v];
    }
}
#define NOEDGE 999999
static void floyd(int n, int w[][8], long d[][8]) {
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) d[i][j] = i == j ? 0 : (w[i][j] ? w[i][j] : NOEDGE);
    for (int k = 0; k < n; k++) for (int i = 0; i < n; i++) for (int j = 0; j < n; j++)
        if (d[i][k] + d[k][j] < d[i][j]) d[i][j] = d[i][k] + d[k][j];
}
/* ---- Bellman-Ford with negative-cycle detection ---- */
typedef struct { int u, v, w; } Edge;
static int bellman_ford(int n, Edge *e, int m, int src, long dist[]) {
    for (int v = 0; v < n; v++) dist[v] = LONG_MAX / 4;
    dist[src] = 0;
    for (int pass = 0; pass < n - 1; pass++) for (int i = 0; i < m; i++) if (dist[e[i].u] + e[i].w < dist[e[i].v]) dist[e[i].v] = dist[e[i].u] + e[i].w;
    for (int i = 0; i < m; i++) if (dist[e[i].u] + e[i].w < dist[e[i].v]) return 1;      /* still improving: negative cycle */
    return 0;
}
int main(void) {
    printf("TEST 1: unreachable destination\n");
    int w1[8][8] = {{0}}; w1[0][1] = w1[1][0] = 4; w1[1][2] = w1[2][1] = 3;            /* vertex 3 has no road at all */
    int d[8]; dijkstra(4, w1, 0, d);
    for (int v = 0; v < 4; v++) { if (d[v] == INF) printf("  0 -> %d: unreachable\n", v); else printf("  0 -> %d: %d\n", v, d[v]); }

    printf("TEST 2: one negative edge (0->1 = 4, 0->2 = 5, 2->1 = -3); the true shortest 0->1 is 2 via vertex 2\n");
    int w2[8][8] = {{0}}; w2[0][1] = 4; w2[0][2] = 5; w2[2][1] = -3;
    dijkstra(3, w2, 0, d);
    long fw[8][8]; floyd(3, w2, fw);
    printf("  Dijkstra   0->1 = %d   (WRONG: vertex 1 was finalised with 4 before the edge 2->1 was seen)\n", d[1]);
    printf("  Floyd-W.   0->1 = %ld  (correct)\n", fw[0][1]);
    Edge e2[3] = {{0,1,4},{0,2,5},{2,1,-3}}; long bf[8]; int neg = bellman_ford(3, e2, 3, 0, bf);
    printf("  Bellman-Ford 0->1 = %ld, negative cycle: %s\n", bf[1], neg ? "yes" : "no");
    Edge e3[4] = {{0,1,1},{1,2,-3},{2,1,1},{0,2,9}}; neg = bellman_ford(3, e3, 4, 0, bf);
    printf("  graph with cycle 1->2->1 of weight -2: Bellman-Ford reports negative cycle: %s\n", neg ? "yes" : "no");

    printf("TEST 3: huge travel times (two edges of 2,000,000,000 minutes)\n");
    int a = 2000000000, b = 2000000000;
    int wrapped = (int)((unsigned)a + (unsigned)b);       /* what a 32-bit int addition does in practice (signed overflow is undefined) */
    printf("  int sum a + b wraps to %d, which is smaller than a, so  'dist[u] + w < dist[v]'  would be TRUE and corrupt dist\n", wrapped);
    long long safe = (long long)a + b;
    printf("  with long long: %lld;  guarded test  (w > INT_MAX - dist[u])  -> %s\n", safe, b > INT_MAX - a ? "edge skipped, no overflow" : "ok");
    int dist_u = INF; int wt = 5;
    printf("  adding a weight to INF: (unsigned)INT_MAX + 5 as int = %d (negative!)  -> that is why only vertices with dist != INF are selected\n", (int)((unsigned)dist_u + (unsigned)wt));

    printf("TEST 4: topological sort of a task graph with a cycle (Kahn)\n");
    int g[4][4] = {{0,1,0,0},{0,0,1,0},{0,0,0,1},{0,1,0,0}};      /* 1 -> 2 -> 3 -> 1 */
    int indeg[4] = {0}, q[4], h = 0, t = 0, done = 0;
    for (int u = 0; u < 4; u++) for (int v = 0; v < 4; v++) indeg[v] += g[u][v];
    for (int v = 0; v < 4; v++) if (!indeg[v]) q[t++] = v;
    while (h < t) { int u = q[h++]; done++; for (int v = 0; v < 4; v++) if (g[u][v] && --indeg[v] == 0) q[t++] = v; }
    printf("  tasks ordered: %d of 4  -> %s\n", done, done == 4 ? "valid schedule" : "cycle detected");
    return 0;
}

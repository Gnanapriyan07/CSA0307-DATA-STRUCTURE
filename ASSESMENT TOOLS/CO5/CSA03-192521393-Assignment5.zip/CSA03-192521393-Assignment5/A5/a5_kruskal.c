/* A5 alternative: Kruskal (sort edges + union-find) on the assignment graph, then Prim vs Kruskal timing */
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
typedef struct { int u, v, w; } E;
static int cmp(const void *a, const void *b) { return ((const E *)a)->w - ((const E *)b)->w; }
static int *par, *rk;
static int find(int x) { while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; } return x; }
static int unite(int a, int b) { a = find(a); b = find(b); if (a == b) return 0; if (rk[a] < rk[b]) { int t = a; a = b; b = t; } par[b] = a; if (rk[a] == rk[b]) rk[a]++; return 1; }
static long kruskal(E *e, int m, int V, int print) {
    qsort(e, (size_t)m, sizeof *e, cmp);
    for (int i = 0; i < V; i++) { par[i] = i; rk[i] = 0; }
    long total = 0;
    for (int i = 0; i < m; i++) if (unite(e[i].u, e[i].v)) { total += e[i].w; if (print) printf("%d-%d(%d) ", e[i].u, e[i].v, e[i].w); }
    return total;
}
/* Prim, array version on an edge list converted to a matrix (0 = none) */
static long prim(int *c, int V) {
    int *key = malloc(V * sizeof *key); char *in = calloc(V, 1); long total = 0;
    for (int i = 0; i < V; i++) key[i] = INT_MAX;
    key[0] = 0;
    for (int k = 0; k < V; k++) { int u = -1; for (int v = 0; v < V; v++) if (!in[v] && (u < 0 || key[v] < key[u])) u = v;
        if (key[u] == INT_MAX) break;
        in[u] = 1; total += key[u];
        for (int v = 0; v < V; v++) if (!in[v] && c[u*V+v] > 0 && c[u*V+v] < key[v]) key[v] = c[u*V+v]; }
    free(key); free(in); return total;
}
int main(void) {
    int c5[5][5] = {{0,2,0,6,0},{2,0,3,8,5},{0,3,0,0,7},{6,8,0,0,9},{0,5,7,9,0}};
    E e[16]; int m = 0;
    for (int i = 0; i < 5; i++) for (int j = i + 1; j < 5; j++) if (c5[i][j]) e[m++] = (E){i, j, c5[i][j]};
    par = malloc(5000 * sizeof *par); rk = malloc(5000 * sizeof *rk);
    printf("Kruskal on the 5-village graph: ");
    long t = kruskal(e, m, 5, 1); printf("\ntotal cost = %ld\n", t);
    printf("\nsparse and dense graphs, V = 2000 (times in ms, both give the same total):\n");
    int V = 2000;
    for (int dense = 0; dense < 2; dense++) {
        int *c = calloc((size_t)V * V, sizeof *c); int cap = dense ? V * V / 4 : 3 * V; E *ed = malloc((size_t)(cap + V) * sizeof *ed); int k = 0;
        srand(8);
        for (int i = 0; i + 1 < V; i++) { int w = 1 + rand() % 1000; c[i*V+i+1] = c[(i+1)*V+i] = w; ed[k++] = (E){i, i+1, w}; }
        for (int r = 0; r < cap - V; r++) { int a = rand() % V, b = rand() % V; if (a == b || c[a*V+b]) continue; int w = 1 + rand() % 1000; c[a*V+b] = c[b*V+a] = w; ed[k++] = (E){a, b, w}; }
        clock_t t0 = clock(); long tp = prim(c, V); double ms_p = (double)(clock() - t0) * 1000 / CLOCKS_PER_SEC;
        t0 = clock(); long tk = kruskal(ed, k, V, 0); double ms_k = (double)(clock() - t0) * 1000 / CLOCKS_PER_SEC;
        printf("%-6s E=%-8d Prim(array) %8.2f ms   Kruskal %8.2f ms   totals %ld / %ld %s\n", dense ? "dense" : "sparse", k, ms_p, ms_k, tp, tk, tp == tk ? "(equal)" : "(DIFFERENT)");
        free(c); free(ed);
    }
    return 0;
}

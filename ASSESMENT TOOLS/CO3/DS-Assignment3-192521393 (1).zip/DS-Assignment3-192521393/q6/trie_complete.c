#include <stdio.h>
#include <stdlib.h>
typedef struct Trie {
 struct Trie *child[26];
 int words;
 int end;
} Trie;
Trie *node(void) { return calloc(1, sizeof(Trie)); }
void insert(Trie *t, const char *w)
{
    t->words++;
    for (; *w; w++) {
        int i = *w - 'a';
        if (!t->child[i]) t->child[i] = node();
        t = t->child[i];
        t->words++;
    }
    t->end = 1;
}
int count_prefix(const Trie *t, const char *p)
{
    for (; *p; p++) {
        t = t->child[*p - 'a'];
        if (!t) return 0;
    }
    return t->words;
}
void destroy(Trie *t)
{
 if (!t) return;
 for (int i = 0; i < 26; i++) destroy(t->child[i]);
 free(t);
}
int count_nodes(const Trie *t){ if(!t) return 0; int c=1; for(int i=0;i<26;i++) c+=count_nodes(t->child[i]); return c; }

const Trie *find(const Trie *t, const char *p) {
    for (; *p; p++) { t = t->child[*p - 'a']; if (!t) return NULL; }
    return t;
}
int search(const Trie *t, const char *w) { const Trie *n = find(t, w); return n && n->end; }
void collect(const Trie *t, char *buf, int len) {
    if (t->end) { buf[len] = 0; printf("  %s\n", buf); }
    for (int i = 0; i < 26; i++)
        if (t->child[i]) { buf[len] = 'a' + i; collect(t->child[i], buf, len + 1); }
}
void autocomplete(const Trie *t, const char *p) {
    char buf[64]; int len = 0;
    for (const char *q = p; *q; q++) buf[len++] = *q;
    const Trie *n = find(t, p);
    printf("autocomplete \"%s\":\n", p);
    if (n) collect(n, buf, len);
}
void erase(Trie *root, const char *w) {
    if (!search(root, w)) return;
    Trie *t = root; t->words--;
    for (; *w; w++) {
        int i = *w - 'a';
        Trie *c = t->child[i];
        if (--c->words == 0) { destroy(c); t->child[i] = NULL; return; }
        t = c;
    }
    t->end = 0;
}
int main(void)
{
 const char *contacts[] = {"anand", "anitha", "anu", "arun", "bala", "anusuya"};
 Trie *root = node();
 for (int i = 0; i < 6; i++) insert(root, contacts[i]);
 const char *typed[] = {"a", "an", "anu", "b", "z"};
 for (int i = 0; i < 5; i++)
 printf("%s:%d ", typed[i], count_prefix(root, typed[i]));
 printf("\n");
 printf("nodes=%d  sizeof(Trie)=%zu  memory=%zu bytes\n", count_nodes(root), sizeof(Trie), count_nodes(root)*sizeof(Trie));
 autocomplete(root, "an");
 autocomplete(root, "a");
 autocomplete(root, "anu");
 autocomplete(root, "z");
 printf("empty prefix count = %d\n", count_prefix(root, ""));
 erase(root, "anu");
 printf("anu:%d anusuya:%d count(anu)=%d\n", search(root,"anu"), search(root,"anusuya"), count_prefix(root,"anu"));
 destroy(root);
 return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef struct Trie { struct Trie *child[26]; int words; int end; } Trie;
static long nodes_created = 0;
Trie *node(void) { nodes_created++; return calloc(1, sizeof(Trie)); }
void insert(Trie *t, const char *w) {
    t->words++;
    for (; *w; w++) { int i = *w - 'a'; if (!t->child[i]) t->child[i] = node(); t = t->child[i]; t->words++; }
    t->end = 1;
}
int count_prefix(const Trie *t, const char *p) {
    for (; *p; p++) { t = t->child[*p - 'a']; if (!t) return 0; }
    return t->words;
}
int cmp(const void *a, const void *b) { return strcmp(*(char *const *)a, *(char *const *)b); }
int lower_bound(char **a, int n, const char *p) {
    int lo = 0, hi = n;
    while (lo < hi) { int m = (lo + hi) / 2; if (strcmp(a[m], p) < 0) lo = m + 1; else hi = m; }
    return lo;
}
void bench(int n) {
    char **names = malloc(n * sizeof *names); long chars = 0;
    for (int i = 0; i < n; i++) {
        int len = 4 + rand() % 7;
        names[i] = malloc(len + 1);
        for (int j = 0; j < len; j++) names[i][j] = 'a' + rand() % 26;
        names[i][len] = 0; chars += len + 1;
    }
    nodes_created = 0;
    Trie *root = node();
    for (int i = 0; i < n; i++) insert(root, names[i]);
    qsort(names, n, sizeof *names, cmp);
    long hits = 0; clock_t t0 = clock();
    for (int q = 0; q < 200000; q++) { char p[4] = { 'a' + rand()%26, 'a' + rand()%26, 'a' + rand()%26, 0 }; hits += count_prefix(root, p); }
    double t_trie = (double)(clock() - t0) / CLOCKS_PER_SEC / 200000 * 1e6;
    t0 = clock();
    for (int q = 0; q < 200000; q++) {
        char p[4] = { 'a' + rand()%26, 'a' + rand()%26, 'a' + rand()%26, 0 };
        int lo = lower_bound(names, n, p);
        p[2]++;
        hits += lower_bound(names, n, p) - lo;
    }
    double t_arr = (double)(clock() - t0) / CLOCKS_PER_SEC / 200000 * 1e6;
    printf("n=%6d  trie: %.3f us/query, %.2f MB (%ld nodes) | array: %.3f us/query, %.3f MB | hits=%ld\n",
           n, t_trie, nodes_created * sizeof(Trie) / 1048576.0, nodes_created,
           t_arr, (chars + n * sizeof(char *)) / 1048576.0, hits);
}
int main(void){ srand(1); bench(500); bench(5000); bench(50000); return 0; }

#!/bin/sh
# Compiles and runs every program. Output of each run is saved in outputs/<name>.txt
set -e
mkdir -p outputs bin
run() { # dir source flags [args]
  d=$1; s=$2; f=$3; shift 3
  gcc -Wall $f "$d/$s.c" -o "bin/$s"
  echo "== $d/$s"
  (cd $d && ../bin/$s "$@") | tee "outputs/$s.txt"
}
ASAN="-g -fsanitize=address"
run q1 predict1 "$ASAN"
run q1 predict2 "$ASAN"
run q1 complete_code "$ASAN"
run q1 q1_bst "$ASAN"
run q2 avl_complete "$ASAN"
run q2 q2_avl_bench "-O2"
run q3 q3_btree "$ASAN"
run q4 q4_rbtree "$ASAN"
run q5 q5_splay "$ASAN"
run q6 trie_complete "$ASAN"
run q6 q6_bench "-O2"
run q7 q7_dictionary "$ASAN"
mv outputs/q7_dictionary.txt outputs/q7_dictionary_sample.txt
run q7 q7_dictionary "$ASAN" words.txt
mv outputs/q7_dictionary.txt outputs/q7_dictionary_words.txt

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef struct T {
    unsigned char c, end;
    struct T *child, *sib;
} T;
static long nodes = 0;
T *newT(unsigned char c) { T *n = calloc(1, sizeof *n); n->c = c; nodes++; return n; }
void insert(T *root, const char *w) {
    T *cur = root;
    for (; *w; w++) {
        unsigned char ch = (unsigned char)*w;
        T **p = &cur->child;
        while (*p && (*p)->c < ch) p = &(*p)->sib;
        if (!*p || (*p)->c != ch) { T *n = newT(ch); n->sib = *p; *p = n; }
        cur = *p;
    }
    cur->end = 1;
}
const T *find(const T *root, const char *p) {
    const T *cur = root;
    for (; *p; p++) {
        unsigned char ch = (unsigned char)*p;
        const T *c = cur->child;
        while (c && c->c < ch) c = c->sib;
        if (!c || c->c != ch) return NULL;
        cur = c;
    }
    return cur;
}
int lookup(const T *root, const char *w) { const T *n = find(root, w); return n && n->end; }
void walk(const T *n, char *buf, int len, int *left) {
    if (*left <= 0) return;
    if (n->end) { buf[len] = 0; printf("  %s\n", buf); (*left)--; }
    for (const T *c = n->child; c && *left > 0; c = c->sib) { buf[len] = c->c; walk(c, buf, len + 1, left); }
}
void autocomplete(const T *root, const char *p, int k) {
    char buf[64]; strcpy(buf, p);
    const T *n = find(root, p);
    printf("autocomplete \"%s\":\n", p);
    if (n) walk(n, buf, (int)strlen(p), &k);
}
void range(const T *n, char *buf, int len, const char *lo, const char *hi) {
    for (const T *c = n->child; c; c = c->sib) {
        buf[len] = c->c; buf[len + 1] = 0;
        if (strncmp(buf, hi, len + 1) > 0) return;
        if (strncmp(buf, lo, len + 1) < 0) continue;
        if (c->end && strcmp(buf, lo) >= 0 && strcmp(buf, hi) <= 0) printf("  %s\n", buf);
        range(c, buf, len + 1, lo, hi);
    }
}
void spell(const T *n, const char *w, int m, const int *prev, char *buf, int len, int maxd) {
    for (; n; n = n->sib) {
        int cur[64], best; buf[len] = n->c;
        cur[0] = prev[0] + 1; best = cur[0];
        for (int j = 1; j <= m; j++) {
            int v = prev[j - 1] + (w[j - 1] != (char)n->c);
            if (prev[j] + 1 < v) v = prev[j] + 1;
            if (cur[j - 1] + 1 < v) v = cur[j - 1] + 1;
            cur[j] = v; if (v < best) best = v;
        }
        if (n->end && cur[m] <= maxd) { buf[len + 1] = 0; printf("  %s\n", buf); }
        if (best <= maxd) spell(n->child, w, m, cur, buf, len + 1, maxd);
    }
}
void suggest(const T *root, const char *w, int maxd) {
    int m = (int)strlen(w), prev[64]; char buf[64];
    for (int j = 0; j <= m; j++) prev[j] = j;
    printf("suggestions for \"%s\":\n", w);
    spell(root->child, w, m, prev, buf, 0, maxd);
}
void destroy(T *n) { if (n) { destroy(n->child); destroy(n->sib); free(n); } }
int main(int argc, char **argv) {
    const char *sample[] = {"anand", "anitha", "anu", "anusuya", "arun", "bala",
                            "balan", "bharath", "kavin", "kumar", "priya", "priyan"};
    T *root = newT(0); int count = 0; char line[64];
    if (argc > 1) {
        FILE *fp = fopen(argv[1], "r");
        while (fp && fgets(line, sizeof line, fp)) { line[strcspn(line, "\r\n")] = 0; if (*line) { insert(root, line); count++; } }
        if (fp) fclose(fp);
    } else for (int i = 0; i < 12; i++) { insert(root, sample[i]); count++; }
    printf("words=%d nodes=%ld memory=%.3f MB\n", count, nodes, nodes * sizeof(T) / 1048576.0);
    if (argc > 1) {
        /* verification against the file itself */
        FILE *fp = fopen(argv[1], "r"); int ok = 0, tot = 0;
        while (fgets(line, sizeof line, fp)) { line[strcspn(line, "\r\n")] = 0; if (*line) { tot++; ok += lookup(root, line); } }
        fclose(fp);
        printf("verification: %d of %d words found; lookup(\"zzzzz\")=%d\n", ok, tot, lookup(root, "zzzzz"));
        autocomplete(root, "ka", 5);
        char buf[64];
        printf("range kaka..kari (first lines):\n"); range(root, buf, 0, "kaka", "kari");
        clock_t t0 = clock();
        for (int i = 0; i < 100000; i++) lookup(root, "kakaran");
        printf("lookup time: %.3f us\n", (double)(clock() - t0) / CLOCKS_PER_SEC / 100000 * 1e6);
    } else {
        printf("lookup anu=%d an=%d arun=%d\n", lookup(root, "anu"), lookup(root, "an"), lookup(root, "arun"));
        autocomplete(root, "an", 10);
        char buf[64];
        printf("range anu..bala:\n"); range(root, buf, 0, "anu", "bala");
        suggest(root, "arum", 1);
        clock_t t0 = clock();
        for (int i = 0; i < 100000; i++) lookup(root, "priyan");
        printf("lookup time: %.3f us\n", (double)(clock() - t0) / CLOCKS_PER_SEC / 100000 * 1e6);
    }
    destroy(root);
    return 0;
}

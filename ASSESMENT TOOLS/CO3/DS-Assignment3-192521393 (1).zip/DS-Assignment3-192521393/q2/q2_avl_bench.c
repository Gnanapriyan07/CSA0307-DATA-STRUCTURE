#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef struct Node { int key, h; struct Node *l, *r; } Node;
static long rots = 0;
int ht(Node *n) { return n ? n->h : 0; }
int max(int a, int b) { return a > b ? a : b; }
void fix(Node *n) { n->h = 1 + max(ht(n->l), ht(n->r)); }
Node *rotate_right(Node *y) { Node *x = y->l; y->l = x->r; x->r = y; fix(y); fix(x); rots++; return x; }
Node *rotate_left(Node *x)  { Node *y = x->r; x->r = y->l; y->l = x; fix(x); fix(y); rots++; return y; }
Node *insert(Node *n, int key) {
    if (!n) { n = malloc(sizeof *n); n->key = key; n->h = 1; n->l = n->r = NULL; return n; }
    if (key < n->key) n->l = insert(n->l, key);
    else if (key > n->key) n->r = insert(n->r, key);
    else return n;
    fix(n);
    int bal = ht(n->l) - ht(n->r);
    if (bal > 1 && key < n->l->key) return rotate_right(n);
    if (bal < -1 && key > n->r->key) return rotate_left(n);
    if (bal > 1)  { n->l = rotate_left(n->l);  return rotate_right(n); }
    if (bal < -1) { n->r = rotate_right(n->r); return rotate_left(n); }
    return n;
}
int avl_search(Node *n, int k) {
    while (n) { if (k == n->key) return 1; n = k < n->key ? n->l : n->r; }
    return 0;
}
int check(Node *n) {
    if (!n) return 1;
    int b = ht(n->l) - ht(n->r);
    if (b < -1 || b > 1 || n->h != 1 + max(ht(n->l), ht(n->r))) return 0;
    return check(n->l) && check(n->r);
}
typedef struct B { int key; struct B *l, *r; } B;
int bst_insert(B **root, int k) {
    int d = 0; B **p = root;
    while (*p) { d++; p = k < (*p)->key ? &(*p)->l : &(*p)->r; }
    *p = calloc(1, sizeof(B)); (*p)->key = k;
    return d;
}
int bst_search(B *t, int k) {
    while (t) { if (k == t->key) return 1; t = k < t->key ? t->l : t->r; }
    return 0;
}
double secs(clock_t a) { return (double)(clock() - a) / CLOCKS_PER_SEC; }
int main(void) {
    int n = 100000, *a = malloc(n * sizeof *a);
    for (int i = 0; i < n; i++) a[i] = i + 1;
    B *bt = NULL; Node *av = NULL; int bh = 0; clock_t t0;
    t0 = clock(); for (int i = 0; i < n; i++) { int d = bst_insert(&bt, a[i]); if (d > bh) bh = d; }
    double bst_ins = secs(t0);
    t0 = clock(); for (int i = 0; i < n; i++) av = insert(av, a[i]);
    double avl_ins = secs(t0);
    long sorted_rots = rots;
    int found = 0;
    t0 = clock(); for (int i = 0; i < n; i += 100) found += bst_search(bt, a[i]);
    double bst_s = secs(t0);
    t0 = clock(); for (int i = 0; i < n; i += 100) found += avl_search(av, a[i]);
    double avl_s = secs(t0);
    printf("SORTED  : BST height %d edges, AVL height %d levels\n", bh, ht(av));
    printf("          rotations %ld, balance check %s\n", sorted_rots, check(av) ? "OK" : "FAILED");
    printf("          insert  BST %.3f s  AVL %.4f s\n", bst_ins, avl_ins);
    printf("          1000 searches  BST %.4f s  AVL %.6f s (found=%d)\n", bst_s, avl_s, found);
    srand(7);
    for (int i = n - 1; i > 0; i--) { int j = rand() % (i + 1), t = a[i]; a[i] = a[j]; a[j] = t; }
    Node *ar = NULL; rots = 0;
    t0 = clock(); for (int i = 0; i < n; i++) ar = insert(ar, a[i]);
    printf("RANDOM  : AVL height %d, rotations %ld (%.2f per insert), balance check %s, insert %.4f s\n",
           ht(ar), rots, (double)rots / n, check(ar) ? "OK" : "FAILED", secs(t0));
    return 0;
}

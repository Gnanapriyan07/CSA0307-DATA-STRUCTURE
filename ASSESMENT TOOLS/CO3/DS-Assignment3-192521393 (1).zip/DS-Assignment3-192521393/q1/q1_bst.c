#include <stdio.h>
#include <stdlib.h>

typedef struct Node { int key; struct Node *left, *right; } Node;

Node *newNode(int k) {
    Node *n = malloc(sizeof *n);
    n->key = k; n->left = n->right = NULL;
    return n;
}
Node *insert(Node *r, int k) {
    if (!r) return newNode(k);
    if (k < r->key) r->left = insert(r->left, k);
    else if (k > r->key) r->right = insert(r->right, k);
    return r;
}
int search(Node *r, int k, int *cmp) {
    *cmp = 0;
    while (r) {
        (*cmp)++;
        if (k == r->key) return 1;
        r = k < r->key ? r->left : r->right;
    }
    return 0;
}
int height(Node *r) {
    if (!r) return -1;
    int l = height(r->left), rt = height(r->right);
    return 1 + (l > rt ? l : rt);
}
int count(Node *r) { return r ? 1 + count(r->left) + count(r->right) : 0; }
Node *minNode(Node *r) { while (r && r->left) r = r->left; return r; }
Node *del(Node *r, int k) {
    if (!r) return NULL;
    if (k < r->key) r->left = del(r->left, k);
    else if (k > r->key) r->right = del(r->right, k);
    else if (r->left && r->right) {
        Node *s = minNode(r->right);
        r->key = s->key;
        r->right = del(r->right, s->key);
    } else {
        Node *c = r->left ? r->left : r->right;
        free(r);
        return c;
    }
    return r;
}
void preorder(Node *r)  { if (r) { printf("%d ", r->key); preorder(r->left); preorder(r->right); } }
void inorder(Node *r)   { if (r) { inorder(r->left); printf("%d ", r->key); inorder(r->right); } }
void postorder(Node *r) { if (r) { postorder(r->left); postorder(r->right); printf("%d ", r->key); } }
void levelorder(Node *r) {
    if (!r) return;
    Node **q = malloc(count(r) * sizeof *q);
    int f = 0, b = 0;
    q[b++] = r;
    while (f < b) {
        Node *c = q[f++];
        printf("%d ", c->key);
        if (c->left)  q[b++] = c->left;
        if (c->right) q[b++] = c->right;
    }
    free(q);
}
void savePre(Node *r, FILE *fp) {
    if (r) { fprintf(fp, "%d\n", r->key); savePre(r->left, fp); savePre(r->right, fp); }
}
Node *load(const char *name) {
    FILE *fp = fopen(name, "r");
    Node *r = NULL; int k;
    if (!fp) return NULL;
    while (fscanf(fp, "%d", &k) == 1) r = insert(r, k);
    fclose(fp);
    return r;
}
void destroy(Node *r) { if (r) { destroy(r->left); destroy(r->right); free(r); } }

void report(const char *name, Node *t, int *a, int n) {
    long total = 0; int c, worst = 0;
    for (int i = 0; i < n; i++) {
        search(t, a[i], &c);
        total += c;
        if (c > worst) worst = c;
    }
    printf("%-7s height=%d  avg comparisons=%.2f  worst=%d\n",
           name, height(t), (double)total / n, worst);
}

int main(void) {
    int s[] = {50, 30, 70, 20, 40, 60, 80, 65};
    Node *t = NULL;
    for (int i = 0; i < 8; i++) t = insert(t, s[i]);
    printf("Pre : "); preorder(t);   printf("\n");
    printf("In  : "); inorder(t);    printf("\n");
    printf("Post: "); postorder(t);  printf("\n");
    printf("Level: "); levelorder(t); printf("\n");

    t = del(t, 20); printf("after delete 20 (leaf)      : "); preorder(t); printf("\n");
    t = del(t, 30); printf("after delete 30 (one child) : "); preorder(t); printf("\n");
    t = del(t, 50); printf("after delete 50 (two child) : "); preorder(t); printf("\n");

    FILE *fp = fopen("tree.txt", "w"); savePre(t, fp); fclose(fp);
    Node *u = load("tree.txt");
    printf("rebuilt tree preorder       : "); preorder(u); printf("\n");
    destroy(u); destroy(t);

    int c; Node *e = NULL;
    printf("empty: height=%d search=%d inorder:", height(e), search(e, 5, &c));
    inorder(e); printf(" (nothing)\n");
    e = insert(e, 5); e = insert(e, 5); e = insert(e, 5);
    printf("after inserting 5 three times: count=%d\n", count(e));
    e = del(e, 99);
    e = del(e, 5);
    printf("after deleting 5: count=%d\n", count(e));
    destroy(e);

    int n = 2000;
    int *a = malloc(n * sizeof *a);
    for (int i = 0; i < n; i++) a[i] = 1000 + i;
    Node *sorted = NULL, *rnd = NULL;
    for (int i = 0; i < n; i++) sorted = insert(sorted, a[i]);
    srand(42);
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1), tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    for (int i = 0; i < n; i++) rnd = insert(rnd, a[i]);
    report("random", rnd, a, n);
    report("sorted", sorted, a, n);
    destroy(rnd); destroy(sorted); free(a);
    return 0;
}

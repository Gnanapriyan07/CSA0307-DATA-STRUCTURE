#include <stdio.h>
#include <stdlib.h>
#define T 2
typedef struct B { int n, leaf, k[2*T-1]; struct B *c[2*T]; } B;
B *newnode(int leaf) { B *x = calloc(1, sizeof *x); x->leaf = leaf; return x; }
int search(B *x, int key, int *reads) {
    (*reads)++;
    int i = 0;
    while (i < x->n && key > x->k[i]) i++;
    if (i < x->n && key == x->k[i]) return 1;
    if (x->leaf) return 0;
    return search(x->c[i], key, reads);
}
void split(B *p, int i) {
    B *y = p->c[i], *z = newnode(y->leaf);
    z->n = T - 1;
    for (int j = 0; j < T - 1; j++) z->k[j] = y->k[j + T];
    if (!y->leaf) for (int j = 0; j < T; j++) z->c[j] = y->c[j + T];
    y->n = T - 1;
    for (int j = p->n; j >= i + 1; j--) p->c[j + 1] = p->c[j];
    p->c[i + 1] = z;
    for (int j = p->n - 1; j >= i; j--) p->k[j + 1] = p->k[j];
    p->k[i] = y->k[T - 1];
    p->n++;
}
void insert_nonfull(B *x, int key) {
    int i = x->n - 1;
    if (x->leaf) {
        while (i >= 0 && key < x->k[i]) { x->k[i + 1] = x->k[i]; i--; }
        x->k[i + 1] = key; x->n++;
    } else {
        while (i >= 0 && key < x->k[i]) i--;
        i++;
        if (x->c[i]->n == 2*T - 1) { split(x, i); if (key > x->k[i]) i++; }
        insert_nonfull(x->c[i], key);
    }
}
B *insert(B *r, int key) {
    if (r->n == 2*T - 1) { B *s = newnode(0); s->c[0] = r; split(s, 0); r = s; }
    insert_nonfull(r, key);
    return r;
}
void show(B *x, int depth) {
    printf("%*s[", depth * 4, "");
    for (int i = 0; i < x->n; i++) printf("%s%d", i ? " " : "", x->k[i]);
    printf("]\n");
    if (!x->leaf) for (int i = 0; i <= x->n; i++) show(x->c[i], depth + 1);
}
void destroy(B *x) {
    if (!x->leaf) for (int i = 0; i <= x->n; i++) destroy(x->c[i]);
    free(x);
}
int main(void) {
    int keys[] = {10, 20, 5, 6, 12, 30, 7, 17};
    B *root = newnode(1);
    for (int i = 0; i < 8; i++) {
        root = insert(root, keys[i]);
        printf("after inserting %d:\n", keys[i]);
        show(root, 0);
    }
    int test[] = {5, 30, 17, 99};
    for (int i = 0; i < 4; i++) {
        int reads = 0, f = search(root, test[i], &reads);
        printf("search %d: %s, disk reads = %d\n", test[i], f ? "found" : "not found", reads);
    }
    destroy(root);
    return 0;
}

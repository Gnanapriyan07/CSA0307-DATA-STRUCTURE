#include <stdio.h>
#include <stdlib.h>
typedef struct N { int key, red; struct N *l, *r, *p; } N;
N *root = NULL;
long rots = 0;
void rotl(N *x) {
    N *y = x->r;
    x->r = y->l; if (y->l) y->l->p = x;
    y->p = x->p;
    if (!x->p) root = y; else if (x == x->p->l) x->p->l = y; else x->p->r = y;
    y->l = x; x->p = y; rots++;
}
void rotr(N *y) {
    N *x = y->l;
    y->l = x->r; if (x->r) x->r->p = y;
    x->p = y->p;
    if (!y->p) root = x; else if (y == y->p->l) y->p->l = x; else y->p->r = x;
    x->r = y; y->p = x; rots++;
}
void fixup(N *z) {
    while (z->p && z->p->red) {
        N *g = z->p->p;
        if (z->p == g->l) {
            N *u = g->r;
            if (u && u->red) { z->p->red = 0; u->red = 0; g->red = 1; z = g; }
            else {
                if (z == z->p->r) { z = z->p; rotl(z); }
                z->p->red = 0; g = z->p->p; g->red = 1; rotr(g);
            }
        } else {
            N *u = g->l;
            if (u && u->red) { z->p->red = 0; u->red = 0; g->red = 1; z = g; }
            else {
                if (z == z->p->l) { z = z->p; rotr(z); }
                z->p->red = 0; g = z->p->p; g->red = 1; rotl(g);
            }
        }
    }
    root->red = 0;
}
void insert(int k) {
    N *y = NULL, *x = root;
    while (x) {
        y = x;
        if (k < x->key) x = x->l; else if (k > x->key) x = x->r; else return;
    }
    N *z = calloc(1, sizeof *z);
    z->key = k; z->red = 1; z->p = y;
    if (!y) root = z; else if (k < y->key) y->l = z; else y->r = z;
    fixup(z);
}
int check(N *n) {
    if (!n) return 1;
    if (n->red && ((n->l && n->l->red) || (n->r && n->r->red))) return -1;
    int a = check(n->l), b = check(n->r);
    if (a < 0 || b < 0 || a != b) return -1;
    return a + !n->red;
}
int valid(void) { return (!root || !root->red) && check(root) > 0; }
int height(N *n) {
    if (!n) return -1;
    int a = height(n->l), b = height(n->r);
    return 1 + (a > b ? a : b);
}
N *leftmost(void) { N *x = root; while (x && x->l) x = x->l; return x; }
void pre(N *n) {
    if (n) { printf("%d%c ", n->key, n->red ? 'R' : 'B'); pre(n->l); pre(n->r); }
}
void destroy(N *n) { if (n) { destroy(n->l); destroy(n->r); free(n); } }
int main(void) {
    int a[] = {10, 20, 30, 15, 25, 5};
    for (int i = 0; i < 6; i++) {
        insert(a[i]);
        printf("after %2d: valid=%d  ", a[i], valid()); pre(root); printf("\n");
    }
    printf("smallest = %d\n", leftmost()->key);
    destroy(root); root = NULL; rots = 0;
    int n = 1000, ok = 1;
    for (int i = 1; i <= n; i++) { insert(i); if (!valid()) ok = 0; }
    printf("increasing 1..%d: all valid=%d, height=%d (bound %d), rotations=%ld\n",
           n, ok, height(root), 19, rots);
    destroy(root);
    return 0;
}

# Data Structures - Assignment 3 (CO3)
**Optimized Data Storage and Retrieval Using Tree-Based Structures**

| | |
|---|---|
| Student | Gnana Priyan G |
| Register number | 192521393 |
| Department | IT |
| Year / batch | II year, 2025 batch |
| Faculty | Monoj D |
| Institution | SIMATS Engineering |

## Contents
| Folder | Question | Programs |
|---|---|---|
| `q1/` | BST | `q1_bst.c` (full BST, 4 traversals, 3 deletion cases, save/rebuild, empty tree, duplicates, 2000-key experiment), `predict1.c`, `predict2.c` (predict-the-output), `complete_code.c` (TODO 1 and 2) |
| `q2/` | AVL tree | `avl_complete.c` (TODO 1 and 2, prints tree after every insertion), `q2_avl_bench.c` (100,000 keys, BST vs AVL) |
| `q3/` | B-tree | `q3_btree.c` (insert with splits, search, disk-read counter, t = 2) |
| `q4/` | Red-black tree | `q4_rbtree.c` (insertion, property checker after every step, leftmost node, increasing keys) |
| `q5/` | Splay tree | `q5_splay.c` (zig / zig-zig / zig-zag, 80/5 workload, sorted access, worst case) |
| `q6/` | Trie | `trie_complete.c` (TODO 1 and 2, autocomplete, delete, tests), `q6_bench.c` (trie vs sorted array) |
| `q7/` | Dictionary design | `q7_dictionary.c` (sibling-list trie: look-up, autocomplete, range listing, spell-check), `words.txt` |

Each question folder has a `screenshots/` folder with the program output and the tree diagrams.

## Build and run
Requires `gcc` (tested with gcc 13 on Ubuntu 24.04).

    ./run_all.sh            # compiles and runs everything, saves outputs/*.txt

Single program, with AddressSanitizer:

    gcc -Wall -g -fsanitize=address q1/q1_bst.c -o bin/q1_bst && cd q1 && ../bin/q1_bst

The benchmarks (`q2_avl_bench.c`, `q6_bench.c`) are compiled with `-O2` and without the sanitizer. `q2_avl_bench.c` takes about 10 seconds because the plain BST on sorted input is O(n^2).

## Results measured on my run
| Question | Result |
|---|---|
| Q1 | 2,000 keys: random order height 20, 12.54 avg comparisons; sorted order height 1999, 1000.50 avg comparisons |
| Q2 | 100,000 sorted keys: BST height 99,999 (9.1 s to build); AVL height 17 (0.013 s), 99,983 rotations, all balance factors OK. Random: AVL height 20, 0.70 rotations per insert |
| Q3 | Hand trace matches program: root [10 20], leaves [5 6 7] [12 17] [30]; every search = 2 reads |
| Q4 | All 5 properties valid after every insertion; 1,000 increasing keys: height 16, 983 rotations |
| Q5 | Skewed workload: splay 8.07 vs ideal AVL 9.13 nodes per access; uniform: 12.44 vs 8.98; chain first access visits 1,000 nodes |
| Q6 | 6 contacts: 22 nodes, 4,752 bytes; 50,000 names: trie 0.061 us / 44.25 MB, array 0.630 us / 0.763 MB |
| Q7 | 1,000-word sample: 4,340 nodes, 0.099 MB, 1000/1000 words found |

## Notes
* `q7/words.txt` is a synthetic list of 1,000 pronounceable words generated for testing. Replace it with real dictionary words for the final measurements.
* The screenshots are terminal-style images rendered from the real output of these programs. Replace them with your own screenshots if your faculty requires actual captures.
* Timings depend on the machine; rerun `run_all.sh` to get your own.
* The full report (answers, derivations, hand-traced trees, analysis) is in `report/`.

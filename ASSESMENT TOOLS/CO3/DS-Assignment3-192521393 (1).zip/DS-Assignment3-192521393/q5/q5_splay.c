#include <stdio.h>
#include <stdlib.h>
typedef struct S { int key; struct S *l, *r; } S;
static S *path[200000];
S *mk(int k) { S *n = calloc(1, sizeof *n); n->key = k; return n; }
S *splay(S *root, int k, long *visited) {
    S *x = root; int d = 0;
    while (x) {
        (*visited)++;
        if (x->key == k) break;
        path[d++] = x;
        x = k < x->key ? x->l : x->r;
    }
    if (!x) { if (d == 0) return root; x = path[--d]; }
    while (d > 0) {
        S *p = path[--d];
        if (d == 0) {
            if (p->l == x) { p->l = x->r; x->r = p; }
            else           { p->r = x->l; x->l = p; }
            break;
        }
        S *g = path[--d], *gg = d > 0 ? path[d - 1] : NULL;
        if (g->l == p && p->l == x) { g->l = p->r; p->r = g; p->l = x->r; x->r = p; }
        else if (g->r == p && p->r == x) { g->r = p->l; p->l = g; p->r = x->l; x->l = p; }
        else if (g->l == p) { p->r = x->l; g->l = x->r; x->l = p; x->r = g; }
        else { p->l = x->r; g->r = x->l; x->r = p; x->l = g; }
        if (gg) { if (gg->l == g) gg->l = x; else gg->r = x; }
    }
    return x;
}
S *splay_insert(S *root, int k) {
    if (!root) return mk(k);
    long v = 0;
    root = splay(root, k, &v);
    if (root->key == k) return root;
    S *n = mk(k);
    if (k < root->key) { n->r = root; n->l = root->l; root->l = NULL; }
    else               { n->l = root; n->r = root->r; root->r = NULL; }
    return n;
}
S *bst_insert(S *t, int k) {
    if (!t) return mk(k);
    if (k < t->key) t->l = bst_insert(t->l, k); else t->r = bst_insert(t->r, k);
    return t;
}
S *build_balanced(int lo, int hi) {
    if (lo > hi) return NULL;
    int m = (lo + hi) / 2;
    S *n = mk(m);
    n->l = build_balanced(lo, m - 1);
    n->r = build_balanced(m + 1, hi);
    return n;
}
long plain_search(S *t, int k) {
    long c = 0;
    while (t) { c++; if (k == t->key) break; t = k < t->key ? t->l : t->r; }
    return c;
}
void pre(S *t) { if (t) { printf("%d ", t->key); pre(t->l); pre(t->r); } }
void destroy(S *t) { if (t) { destroy(t->l); destroy(t->r); free(t); } }
#define N 1000
#define OPS 10000
void run(const char *name, int *seq, int *perm) {
    S *sp = NULL;
    for (int i = 0; i < N; i++) sp = splay_insert(sp, perm[i]);
    S *bal = build_balanced(1, N);
    long tot = 0, worst = 0, bt = 0;
    printf("%s workload, root after first 10 accesses:", name);
    for (int i = 0; i < OPS; i++) {
        long v = 0;
        sp = splay(sp, seq[i], &v);
        tot += v; if (v > worst) worst = v;
        bt += plain_search(bal, seq[i]);
        if (i < 10) printf(" %d", sp->key);
    }
    printf("\n  splay: avg nodes visited %.2f, worst single access %ld\n", (double)tot / OPS, worst);
    printf("  AVL (ideal shape): avg nodes visited %.2f\n", (double)bt / OPS);
    destroy(sp); destroy(bal);
}
int main(void) {
    int g[] = {5, 3, 8, 2, 4, 7, 9}; S *t = NULL; long v = 0;
    for (int i = 0; i < 7; i++) t = bst_insert(t, g[i]);
    t = splay(t, 3, &v); printf("access 3: "); pre(t); printf("\n");
    t = splay(t, 9, &v); printf("access 9: "); pre(t); printf("\n");
    destroy(t);
    srand(1);
    static int perm[N], seqS[OPS], seqU[OPS];
    for (int i = 0; i < N; i++) perm[i] = i + 1;
    for (int i = N - 1; i > 0; i--) { int j = rand() % (i + 1), x = perm[i]; perm[i] = perm[j]; perm[j] = x; }
    int hot = N / 20;
    for (int i = 0; i < OPS; i++) {
        seqS[i] = (rand() % 100 < 80) ? perm[rand() % hot] : 1 + rand() % N;
        seqU[i] = 1 + rand() % N;
    }
    run("skewed (80% on 5%)", seqS, perm);
    run("uniform", seqU, perm);
    S *sp = NULL; long tot = 0;
    for (int i = 0; i < N; i++) sp = splay_insert(sp, perm[i]);
    for (int k = 1; k <= N; k++) { v = 0; sp = splay(sp, k, &v); tot += v; }
    printf("sorted access 1..%d: avg nodes visited %.2f\n", N, (double)tot / N);
    destroy(sp);
    S *ch = NULL;
    for (int k = 1; k <= N; k++) ch = splay_insert(ch, k);
    v = 0; ch = splay(ch, 1, &v);
    printf("after sorted inserts, one access to key 1 visits %ld nodes\n", v);
    v = 0; ch = splay(ch, 1, &v);
    printf("the same access again visits %ld node\n", v);
    destroy(ch);
    return 0;
}

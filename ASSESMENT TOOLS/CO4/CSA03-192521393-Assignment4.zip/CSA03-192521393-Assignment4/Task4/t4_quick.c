/* Task 4: evidence for the defects, the repair, and the alternatives */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct { int marks; int id; } Rec;
static long cmp_count; static int depth, max_depth;

/* ---- original quicksort on ints (last element as pivot) ---- */
static void swp(int *a, int *b) { int t = *a; *a = *b; *b = t; }
static void quick(int a[], int lo, int hi) {
    if (lo >= hi) return;
    depth++; if (depth > max_depth) max_depth = depth;
    int p = a[hi], i = lo - 1;
    for (int j = lo; j < hi; j++) { cmp_count++; if (a[j] <= p) { i++; swp(&a[i], &a[j]); } }
    swp(&a[i + 1], &a[hi]);
    quick(a, lo, i);
    quick(a, i + 2, hi);
    depth--;
}
/* ---- repaired: median-of-three pivot, recurse on the smaller part, loop on the larger ---- */
static void quick2(int a[], int lo, int hi) {
    depth++; if (depth > max_depth) max_depth = depth;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < a[lo]) swp(&a[mid], &a[lo]);
        if (a[hi] < a[lo]) swp(&a[hi], &a[lo]);
        if (a[hi] < a[mid]) swp(&a[hi], &a[mid]);
        swp(&a[mid], &a[hi]);                       /* median now at the end = pivot */
        int p = a[hi], i = lo - 1;
        for (int j = lo; j < hi; j++) { cmp_count++; if (a[j] <= p) { i++; swp(&a[i], &a[j]); } }
        swp(&a[i + 1], &a[hi]);
        int q = i + 1;
        if (q - lo < hi - q) { quick2(a, lo, q - 1); lo = q + 1; }
        else                 { quick2(a, q + 1, hi); hi = q - 1; }
    }
    depth--;
}
/* ---- original quicksort on records, to show instability ---- */
static void rswp(Rec *a, Rec *b) { Rec t = *a; *a = *b; *b = t; }
static void rquick(Rec a[], int lo, int hi) {
    if (lo >= hi) return;
    int p = a[hi].marks, i = lo - 1;
    for (int j = lo; j < hi; j++) if (a[j].marks <= p) { i++; rswp(&a[i], &a[j]); }
    rswp(&a[i + 1], &a[hi]);
    rquick(a, lo, i); rquick(a, i + 2, hi);
}
/* ---- stable merge sort on records ---- */
static void msort(Rec a[], Rec t[], int lo, int hi) {
    if (lo >= hi) return;
    int mid = lo + (hi - lo) / 2; msort(a, t, lo, mid); msort(a, t, mid + 1, hi);
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) t[k++] = (a[i].marks <= a[j].marks) ? a[i++] : a[j++];
    while (i <= mid) t[k++] = a[i++];
    while (j <= hi) t[k++] = a[j++];
    memcpy(&a[lo], &t[lo], (hi - lo + 1) * sizeof(Rec));
}
/* ---- counting sort (stable) on marks 0..100 ---- */
static void csort(Rec a[], Rec out[], int n) {
    int c[102] = {0};
    for (int i = 0; i < n; i++) c[a[i].marks + 1]++;
    for (int k = 0; k < 101; k++) c[k + 1] += c[k];
    for (int i = 0; i < n; i++) out[c[a[i].marks]++] = a[i];
}
static int sorted_ok(int *a, int n) { for (int i = 1; i < n; i++) if (a[i-1] > a[i]) return 0; return 1; }
int main(void) {
    int n = 10000; int *a = malloc(n * sizeof *a);
    srand(11);
    printf("%-34s %-14s %-10s\n", "case", "comparisons", "max depth");
    for (int rep = 0; rep < 4; rep++) {
        for (int i = 0; i < n; i++) a[i] = (rep % 2 == 0) ? rand() % 101 : i % 101;
        if (rep % 2 == 1) { for (int i = 0; i < n; i++) a[i] = i / 100; }     /* sorted marks 0..99 */
        cmp_count = 0; depth = 0; max_depth = 0;
        if (rep < 2) quick(a, 0, n - 1); else quick2(a, 0, n - 1);
        printf("%-34s %-14ld %-10d sorted=%d\n",
               rep == 0 ? "original, 10,000 random marks" : rep == 1 ? "original, 10,000 sorted marks" :
               rep == 2 ? "repaired, 10,000 random marks" : "repaired, 10,000 sorted marks",
               cmp_count, max_depth, sorted_ok(a, n));
    }
    /* distinct sorted keys, original: worst case n(n-1)/2 */
    for (int i = 0; i < n; i++) a[i] = i;
    cmp_count = 0; depth = 0; max_depth = 0; quick(a, 0, n - 1);
    printf("%-34s %-14ld %-10d (n(n-1)/2 = %ld)\n", "original, 10,000 distinct sorted", cmp_count, max_depth, (long)n * (n - 1) / 2);
    for (int i = 0; i < n; i++) a[i] = i;
    cmp_count = 0; depth = 0; max_depth = 0; quick2(a, 0, n - 1);
    printf("%-34s %-14ld %-10d\n", "repaired, 10,000 distinct sorted", cmp_count, max_depth);

    /* stability demonstration */
    Rec r[8] = {{70,1},{85,2},{70,3},{90,4},{85,5},{70,6},{60,7},{85,8}}, r2[8], t[8], o[8];
    memcpy(r2, r, sizeof r);
    rquick(r, 0, 7);
    printf("original quicksort : "); for (int i = 0; i < 8; i++) printf("%d:#%d ", r[i].marks, r[i].id); printf("\n");
    memcpy(r, r2, sizeof r); msort(r, t, 0, 7);
    printf("merge sort (stable): "); for (int i = 0; i < 8; i++) printf("%d:#%d ", r[i].marks, r[i].id); printf("\n");
    csort(r2, o, 8);
    printf("counting sort      : "); for (int i = 0; i < 8; i++) printf("%d:#%d ", o[i].marks, o[i].id); printf("\n");
    free(a);
    return 0;
}

/* Task 6: order processing - hash table (look-up by ID) + indexed min-heap (most delayed order)
   + stable merge sort (hourly report).  Build: gcc -std=c11 -Wall -Wextra -O2 t6_orders.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    unsigned id;          /* order ID (key) */
    int restaurant;       /* 0..1999 */
    int amount;           /* rupees */
    long promised;        /* promised delivery time in seconds since start of the hour */
    int next;             /* next order in the same hash bucket, -1 = end */
    int heap_pos;         /* position in the heap, -1 if not in the heap */
    int state;            /* 0 waiting, 1 assigned to a rider, 2 cancelled */
} Order;

static Order *ord; static int n_ord = 0, cap_ord;
/* ---------- hash table: separate chaining over the order pool ---------- */
static int *bucket; static unsigned nb, bits; static int rehashes = 0; static double rehash_ms = 0;
static unsigned hidx(unsigned id) { return (unsigned)((id * 2654435761u) >> (32 - bits)); }   /* multiplicative (Fibonacci) hash */
static void table_init(unsigned b) { bits = b; nb = 1u << b; bucket = malloc(nb * sizeof *bucket); for (unsigned i = 0; i < nb; i++) bucket[i] = -1; }
static void rehash(void) {
    clock_t t0 = clock(); free(bucket); table_init(bits + 1);
    for (int i = 0; i < n_ord; i++) { unsigned h = hidx(ord[i].id); ord[i].next = bucket[h]; bucket[h] = i; }
    rehashes++; rehash_ms += (double)(clock() - t0) * 1000.0 / CLOCKS_PER_SEC;
}
static int find(unsigned id) { for (int i = bucket[hidx(id)]; i != -1; i = ord[i].next) if (ord[i].id == id) return i; return -1; }
/* ---------- indexed min-heap on (promised, arrival) ---------- */
static int *heap; static int hn = 0;
static int before(int a, int b) { return ord[a].promised < ord[b].promised || (ord[a].promised == ord[b].promised && a < b); }
static void hset(int p, int o) { heap[p] = o; ord[o].heap_pos = p; }
static void up(int i) { int o = heap[i]; while (i > 0 && before(o, heap[(i-1)/2])) { hset(i, heap[(i-1)/2]); i = (i-1)/2; } hset(i, o); }
static void down(int i) {
    int o = heap[i];
    for (;;) { int l = 2*i+1, r = l+1, b = -1;
        if (l < hn) b = l;
        if (r < hn && before(heap[r], heap[l])) b = r;
        if (b < 0 || !before(heap[b], o)) break;
        hset(i, heap[b]); i = b; }
    hset(i, o);
}
/* ---------- the four operations ---------- */
static void place(unsigned id, int rest, int amount, long promised) {          /* O(1) avg + O(log n) */
    if (n_ord == cap_ord) { cap_ord *= 2; ord = realloc(ord, (size_t)cap_ord * sizeof *ord); }
    int i = n_ord++; ord[i] = (Order){id, rest, amount, promised, -1, -1, 0};
    if ((unsigned)n_ord > nb) rehash();                                          /* grow when load factor > 1 */
    unsigned h = hidx(id); ord[i].next = bucket[h]; bucket[h] = i;
    heap[hn] = i; ord[i].heap_pos = hn; hn++; up(hn - 1);
}
static int assign(void) {                                                         /* O(log n) */
    if (hn == 0) return -1;
    int top = heap[0]; ord[top].heap_pos = -1; ord[top].state = 1;
    hn--; if (hn > 0) { hset(0, heap[hn]); down(0); }
    return top;
}
static int cancel(unsigned id) {                                                  /* O(1) avg + O(log n) */
    int i = find(id); if (i < 0 || ord[i].state != 0) return 0;
    int p = ord[i].heap_pos; ord[i].heap_pos = -1; ord[i].state = 2;
    hn--;
    if (p < hn) { hset(p, heap[hn]); up(p); down(ord[heap[p]].heap_pos); }
    return 1;
}
static int lookup(unsigned id) { return find(id); }                              /* O(1) average */
/* ---------- hourly report: stable merge sort by (restaurant, amount) ---------- */
static int *rep, *tmp;
static void rsort(int lo, int hi) {
    if (lo >= hi) return;
    int mid = lo + (hi - lo) / 2; rsort(lo, mid); rsort(mid + 1, hi);
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        Order *a = &ord[rep[i]], *b = &ord[rep[j]];
        int le = a->restaurant < b->restaurant || (a->restaurant == b->restaurant && a->amount <= b->amount);   /* <= : stable */
        tmp[k++] = le ? rep[i++] : rep[j++];
    }
    while (i <= mid) tmp[k++] = rep[i++];
    while (j <= hi) tmp[k++] = rep[j++];
    memcpy(&rep[lo], &tmp[lo], (size_t)(hi - lo + 1) * sizeof(int));
}
static int report(void) { int m = 0; for (int i = 0; i < n_ord; i++) if (ord[i].state != 2) rep[m++] = i; rsort(0, m - 1); return m; }
static double ms(clock_t a) { return (double)(clock() - a) * 1000.0 / CLOCKS_PER_SEC; }

static void simulate(int N) {
    n_ord = 0; hn = 0; rehashes = 0; rehash_ms = 0; cap_ord = 1024;
    ord = malloc((size_t)cap_ord * sizeof *ord); heap = malloc((size_t)N * sizeof *heap);
    rep = malloc((size_t)N * sizeof *rep); tmp = malloc((size_t)N * sizeof *tmp); table_init(14);
    srand(99); unsigned *ids = malloc((size_t)N * sizeof *ids);
    printf("\n=== %d orders ===\n", N);
    clock_t t0 = clock();
    for (int i = 0; i < N; i++) { ids[i] = (unsigned)(i + 1) * 40503u + 7u; place(ids[i], rand() % 2000, 100 + rand() % 900, rand() % 3600); }
    double t_place = ms(t0);
    printf("place    %d orders : %8.2f ms  (%.3f us each), rehashes=%d (%.2f ms in rehashing), final table=%u buckets, load factor %.2f\n",
           N, t_place, t_place * 1000 / N, rehashes, rehash_ms, nb, (double)N / nb);
    t0 = clock(); long found = 0; for (int i = 0; i < N; i++) found += lookup(ids[rand() % N]) >= 0;
    double t_look = ms(t0); printf("look-up  %d orders : %8.2f ms  (%.3f us each, all %s)\n", N, t_look, t_look * 1000 / N, found == N ? "found" : "NOT all found");
    int ncancel = N / 10; t0 = clock(); int done = 0;
    for (int i = 0; i < ncancel; i++) done += cancel(ids[rand() % N]);
    double t_can = ms(t0); printf("cancel   %d requests: %8.2f ms  (%.3f us each, %d actually cancelled)\n", ncancel, t_can, t_can * 1000 / ncancel, done);
    int nassign = N / 2; long last = -1; int order_ok = 1, cancelled_ok = 1; t0 = clock();
    for (int i = 0; i < nassign; i++) { int o = assign(); if (o < 0) break; if (ord[o].promised < last) order_ok = 0; last = ord[o].promised; if (ord[o].state == 2) cancelled_ok = 0; }
    double t_as = ms(t0); printf("assign   %d orders : %8.2f ms  (%.3f us each), most-delayed-first order %s, no cancelled order assigned: %s\n",
           nassign, t_as, t_as * 1000 / nassign, order_ok ? "correct" : "WRONG", cancelled_ok ? "yes" : "NO");
    t0 = clock(); int m = report(); double t_rep = ms(t0);
    int stable = 1;
    for (int i = 1; i < m; i++) { Order *a = &ord[rep[i-1]], *b = &ord[rep[i]];
        if (a->restaurant > b->restaurant || (a->restaurant == b->restaurant && a->amount > b->amount)) stable = 0;
        if (a->restaurant == b->restaurant && a->amount == b->amount && rep[i-1] > rep[i]) stable = 0; }
    printf("report   %d orders : %8.2f ms  (sorted by restaurant, then amount; equal amounts in arrival order: %s)\n", m, t_rep, stable ? "yes" : "NO");
    free(ord); free(heap); free(rep); free(tmp); free(bucket); free(ids);
}
/* ---------- alternative: one array, re-sorted whenever a rider is free ---------- */
static int cmp_o(const void *a, const void *b) { const Order *x = a, *y = b; return x->promised < y->promised ? -1 : x->promised > y->promised; }
static void alternative(int N, int reps) {
    Order *arr = malloc((size_t)N * sizeof *arr); srand(5);
    for (int i = 0; i < N; i++) arr[i] = (Order){(unsigned)i + 1, rand() % 2000, 100, rand() % 3600, -1, -1, 0};
    clock_t t0 = clock(); for (int r = 0; r < reps; r++) qsort(arr, (size_t)N, sizeof *arr, cmp_o);
    double sort_us = ms(t0) * 1000 / reps;
    t0 = clock(); int hit = 0; for (int r = 0; r < 200; r++) { unsigned id = (unsigned)(rand() % N) + 1; for (int i = 0; i < N; i++) if (arr[i].id == id) { hit++; break; } }
    double scan_us = ms(t0) * 1000 / 200;
    printf("array + re-sort, n=%-6d: %9.1f us per assignment (qsort of the whole array), %8.1f us per look-up by ID (linear scan, %d hits)\n", N, sort_us, scan_us, hit);
    free(arr);
}
int main(void) {
    simulate(50000);
    simulate(100000);
    printf("\n=== alternative design: one array, sort again at every assignment ===\n");
    alternative(5000, 20); alternative(20000, 10); alternative(50000, 5);
    return 0;
}

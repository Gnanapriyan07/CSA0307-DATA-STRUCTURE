/* Task 1.2: compare hash functions on 100,000 generated registration numbers */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#define N 100000
static char reg[N][16];

static unsigned bad_hash(const char *r) { return (unsigned)((r[0] + r[1]) % 1000); }
static uint32_t poly31(const char *s) { uint32_t h = 0; while (*s) h = h * 31u + (unsigned char)*s++; return h; }
static uint64_t fnv1a(const char *s) { uint64_t h = 1469598103934665603ULL; while (*s) { h ^= (unsigned char)*s++; h *= 1099511628211ULL; } return h; }
/* number formed from the registration: base-36 value of all characters, then Knuth multiplication */
static unsigned mult_hash(const char *s, unsigned m) {
    uint64_t k = 0;
    while (*s) { int c = (unsigned char)*s++; k = k * 36 + (c >= 'A' ? c - 'A' + 10 : c - '0'); }
    const double A = 0.6180339887498949;
    double x = (double)(k % 4294967296ULL) * A;
    return (unsigned)(m * (x - (uint64_t)x));
}
typedef unsigned (*hf)(const char *, unsigned);
static unsigned h_bad(const char *s, unsigned m) { (void)m; return bad_hash(s); }
static unsigned h_poly(const char *s, unsigned m) { return poly31(s) % m; }
static unsigned h_fnv(const char *s, unsigned m) { return (unsigned)(fnv1a(s) % m); }
static unsigned h_mul(const char *s, unsigned m) { return mult_hash(s, m); }

static void measure(const char *name, hf f, unsigned m) {
    unsigned *cnt = calloc(m, sizeof *cnt);
    for (int i = 0; i < N; i++) cnt[f(reg[i], m)]++;
    unsigned longest = 0, used = 0;
    for (unsigned b = 0; b < m; b++) { if (cnt[b] > longest) longest = cnt[b]; if (cnt[b]) used++; }
    clock_t t0 = clock(); unsigned sink = 0;
    for (int r = 0; r < 20; r++) for (int i = 0; i < N; i++) sink += f(reg[i], m);
    double ns = (double)(clock() - t0) / CLOCKS_PER_SEC / (20.0 * N) * 1e9;
    printf("%-34s M=%-7u used=%-6u longest=%-6u avg(all)=%.2f avg(non-empty)=%.2f  %.1f ns/hash%s\n",
           name, m, used, longest, (double)N / m, (double)N / used, ns, sink == 1 ? "!" : "");
    free(cnt);
}
int main(void) {
    srand(2026);
    const char *st[] = {"TN","KA","KL","AP","MH","DL","GJ","UP","RJ","WB"};
    for (int i = 0; i < N; i++) {
        const char *s = (rand() % 100 < 80) ? "TN" : st[rand() % 10];
        snprintf(reg[i], 16, "%s%02d%c%c%04d", s, 1 + rand() % 99, 'A' + rand() % 26, 'A' + rand() % 26, rand() % 10000);
    }
    printf("sample: %s %s %s\n", reg[0], reg[1], reg[2]);
    char seen[1000] = {0}; unsigned d = 0;
    for (int i = 0; i < N; i++) seen[bad_hash(reg[i])] = 1;
    for (int b = 0; b < 1000; b++) d += (unsigned)seen[b];
    printf("distinct values produced by the bad hash: %u of 1000\n", d);
    measure("bad hash (reg[0]+reg[1]) % 1000", h_bad, 1000);
    measure("polynomial x31, M=1000", h_poly, 1000);
    measure("polynomial x31, M=100003 (prime)", h_poly, 100003);
    measure("FNV-1a, M=100003 (prime)", h_fnv, 100003);
    measure("multiplication (A=0.618), M=100003", h_mul, 100003);
    return 0;
}

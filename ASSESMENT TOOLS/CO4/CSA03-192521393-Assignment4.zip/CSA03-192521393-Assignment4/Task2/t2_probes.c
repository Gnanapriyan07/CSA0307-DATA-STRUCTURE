/* Task 2.4: measured probes, linear probing and separate chaining */
#include <stdio.h>
#include <stdlib.h>
#define M 100003
static int tab[M]; static int *head, *nxt, *key;
static unsigned h(unsigned k) { k ^= k >> 16; k *= 0x45d9f3bu; k ^= k >> 16; return k % M; }
int main(void) {
    double alphas[] = {0.5, 0.75, 0.9};
    printf("alpha | LP success meas/theory | LP unsucc meas/theory | chain success meas/theory | chain unsucc meas/theory\n");
    for (int a = 0; a < 3; a++) {
        double al = alphas[a]; int n = (int)(al * M);
        srand(7 + a);
        for (int i = 0; i < M; i++) tab[i] = -1;
        key = malloc(n * sizeof *key); head = malloc(M * sizeof *head); nxt = malloc(n * sizeof *nxt);
        for (int i = 0; i < M; i++) head[i] = -1;
        for (int i = 0; i < n; i++) {
            key[i] = (int)((((unsigned)rand() << 8) ^ (unsigned)rand()) & 0x7fffffffu);
            unsigned p = h((unsigned)key[i]); while (tab[p] != -1) p = (p + 1) % M; tab[p] = key[i];
            unsigned b = h((unsigned)key[i]); nxt[i] = head[b]; head[b] = i;
        }
        double ls = 0, lu = 0, cs = 0, cu = 0; int Q = 200000;
        for (int q = 0; q < Q; q++) {
            int k = key[rand() % n]; unsigned p = h((unsigned)k); int pr = 1;
            while (tab[p] != k) { p = (p + 1) % M; pr++; } ls += pr;
            int c = 0; for (int e = head[h((unsigned)k)]; e != -1; e = nxt[e]) { c++; if (key[e] == k) break; } cs += c;
            unsigned u = ((((unsigned)rand() << 8) ^ (unsigned)rand())) | 0x80000000u;   /* absent key */
            p = h(u); pr = 1; while (tab[p] != -1) { p = (p + 1) % M; pr++; } lu += pr;
            c = 0; for (int e = head[h(u)]; e != -1; e = nxt[e]) c++; cu += c;
        }
        printf("%.2f  | %.2f / %.2f | %.2f / %.2f | %.2f / %.2f | %.2f / %.2f\n", al, ls / Q, 0.5 * (1 + 1 / (1 - al)),
               lu / Q, 0.5 * (1 + 1 / ((1 - al) * (1 - al))), cs / Q, 1 + al / 2, cu / Q, al);
        free(key); free(head); free(nxt);
    }
    return 0;
}

#!/bin/bash
# Compile and run every program of Assignment 4.  Usage: ./run_all.sh   (Task 5 sorting takes about 3 minutes)
set -e
G="-std=c11 -Wall -Wextra"; ASAN="-g -fsanitize=address"
run() { d=$1; s=$2; f=$3; echo "== $d/$s"; (cd $d && gcc $G $f $s.c -o $s.bin && ./$s.bin | tee outputs/$s.txt; rm -f $s.bin); }
run Task1 t1_hash "-O2"
run Task2 t2_predict ""
run Task2 t2_complete "$ASAN"
run Task2 t2_probes "-O2"
run Task3 t3_predict ""
run Task3 t3_complete "$ASAN"
run Task3 t3_extra "-O2"
run Task4 t4_predict ""
run Task4 t4_quick "-O2"
run Task5 t5_complete "$ASAN"
run Task5 t5_sort "-O2"
run Task5 t5_parallel "-O2 -fopenmp"
run Task6 t6_orders "-O2"

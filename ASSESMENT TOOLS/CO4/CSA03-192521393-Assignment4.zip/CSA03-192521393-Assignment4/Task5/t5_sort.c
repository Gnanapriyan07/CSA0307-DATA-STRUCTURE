/* Task 5.1: six sorting algorithms, comparisons and time */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static long C;
#define LT(x, y) (C++, (x) < (y))
#define LE(x, y) (C++, (x) <= (y))
static void swp(int *a, int *b) { int t = *a; *a = *b; *b = t; }
static void bubble(int *a, int n) {
    for (int i = 0; i < n - 1; i++) { int sw = 0;
        for (int j = 0; j < n - 1 - i; j++) if (LT(a[j+1], a[j])) { swp(&a[j], &a[j+1]); sw = 1; }
        if (!sw) break; }
}
static void insertion(int *a, int n) {
    for (int i = 1; i < n; i++) { int x = a[i], j = i - 1;
        while (j >= 0 && LT(x, a[j])) { a[j+1] = a[j]; j--; }
        a[j+1] = x; }
}
static void selection(int *a, int n) {
    for (int i = 0; i < n - 1; i++) { int m = i;
        for (int j = i + 1; j < n; j++) if (LT(a[j], a[m])) m = j;
        if (m != i) swp(&a[i], &a[m]); }
}
static void msort(int *a, int *t, int lo, int hi) {
    if (lo >= hi) return;
    int mid = lo + (hi - lo) / 2; msort(a, t, lo, mid); msort(a, t, mid + 1, hi);
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) t[k++] = LE(a[i], a[j]) ? a[i++] : a[j++];
    while (i <= mid) t[k++] = a[i++];
    while (j <= hi) t[k++] = a[j++];
    memcpy(&a[lo], &t[lo], (size_t)(hi - lo + 1) * sizeof(int));
}
static void merge_sort(int *a, int n) { int *t = malloc((size_t)n * sizeof *t); msort(a, t, 0, n - 1); free(t); }
static void quick(int *a, int lo, int hi) {
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (LT(a[mid], a[lo])) swp(&a[mid], &a[lo]);
        if (LT(a[hi], a[lo])) swp(&a[hi], &a[lo]);
        if (LT(a[hi], a[mid])) swp(&a[hi], &a[mid]);
        swp(&a[mid], &a[hi]);
        int p = a[hi], i = lo - 1;
        for (int j = lo; j < hi; j++) if (LE(a[j], p)) { i++; swp(&a[i], &a[j]); }
        swp(&a[i + 1], &a[hi]);
        int q = i + 1;
        if (q - lo < hi - q) { quick(a, lo, q - 1); lo = q + 1; } else { quick(a, q + 1, hi); hi = q - 1; }
    }
}
static void quick_sort(int *a, int n) { quick(a, 0, n - 1); }
static void sift(int *a, int n, int i) {
    for (;;) { int l = 2*i+1, r = l+1, b = i;
        if (l < n && LT(a[b], a[l])) b = l;
        if (r < n && LT(a[b], a[r])) b = r;
        if (b == i) return;
        swp(&a[i], &a[b]); i = b; }
}
static void heap_sort(int *a, int n) {
    for (int i = n/2 - 1; i >= 0; i--) sift(a, n, i);
    for (int e = n - 1; e > 0; e--) { swp(&a[0], &a[e]); sift(a, e, 0); }
}
typedef void (*sf)(int *, int);
int main(void) {
    const char *names[] = {"bubble", "insertion", "selection", "merge", "quick", "heap"};
    sf fn[] = {bubble, insertion, selection, merge_sort, quick_sort, heap_sort};
    int ns[] = {1000, 100000, 1000000};
    const char *pat[] = {"random", "sorted", "reverse"};
    printf("%-10s %-9s %-8s %16s %12s\n", "algorithm", "n", "order", "comparisons", "time (ms)");
    for (int a = 0; a < 6; a++) for (int s = 0; s < 3; s++) for (int p = 0; p < 3; p++) {
        int n = ns[s];
        if (a < 3 && n > 100000) { printf("%-10s %-9d %-8s %16s %12s\n", names[a], n, pat[p], "skipped", "n^2 too slow"); continue; }
        int *x = malloc((size_t)n * sizeof *x); srand(3);
        for (int i = 0; i < n; i++) x[i] = p == 0 ? rand() % 100000 : p == 1 ? i : n - i;
        C = 0; clock_t t0 = clock(); fn[a](x, n);
        double ms = (double)(clock() - t0) * 1000.0 / CLOCKS_PER_SEC;
        int ok = 1; for (int i = 1; i < n; i++) if (x[i-1] > x[i]) ok = 0;
        printf("%-10s %-9d %-8s %16ld %12.2f%s\n", names[a], n, pat[p], C, ms, ok ? "" : "  NOT SORTED");
        fflush(stdout); free(x);
    }
    return 0;
}

/* Task 5.2: merge sort with OpenMP tasks, 10,000,000 orders */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
typedef struct { int order_id; int amount; } Order;
#define CUTOFF 100000
static void merge(Order *a, Order *t, int lo, int mid, int hi) {
    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) t[k++] = (a[i].amount <= a[j].amount) ? a[i++] : a[j++];
    while (i <= mid) t[k++] = a[i++];
    while (j <= hi) t[k++] = a[j++];
    memcpy(&a[lo], &t[lo], (size_t)(hi - lo + 1) * sizeof(Order));
}
static void msort(Order *a, Order *t, int lo, int hi) {
    if (lo >= hi) return;
    int mid = lo + (hi - lo) / 2;
    if (hi - lo < CUTOFF) { msort(a, t, lo, mid); msort(a, t, mid + 1, hi); }
    else {
        #pragma omp task shared(a, t)
        msort(a, t, lo, mid);
        #pragma omp task shared(a, t)
        msort(a, t, mid + 1, hi);
        #pragma omp taskwait
    }
    merge(a, t, lo, mid, hi);
}
int main(void) {
    int n = 10000000;
    Order *orig = malloc((size_t)n * sizeof *orig), *a = malloc((size_t)n * sizeof *a), *t = malloc((size_t)n * sizeof *t);
    srand(1);
    for (int i = 0; i < n; i++) { orig[i].order_id = i; orig[i].amount = rand() % 1000000; }
    printf("cores visible to OpenMP: %d\n", omp_get_num_procs());
    printf("threads  time (s)  speed-up\n");
    double base = 0;
    int th[] = {1, 2, 4, 8};
    for (int k = 0; k < 4; k++) {
        double best = 1e9;
        for (int rep = 0; rep < 2; rep++) {
            memcpy(a, orig, (size_t)n * sizeof *a);
            omp_set_num_threads(th[k]);
            double t0 = omp_get_wtime();
            #pragma omp parallel
            #pragma omp single
            msort(a, t, 0, n - 1);
            double dt = omp_get_wtime() - t0; if (dt < best) best = dt;
        }
        int ok = 1; for (int i = 1; i < n; i++) if (a[i-1].amount > a[i].amount) ok = 0;
        if (k == 0) base = best;
        printf("%-8d %-9.3f %-8.2f %s\n", th[k], best, base / best, ok ? "sorted OK" : "NOT SORTED");
        fflush(stdout);
    }
    return 0;
}

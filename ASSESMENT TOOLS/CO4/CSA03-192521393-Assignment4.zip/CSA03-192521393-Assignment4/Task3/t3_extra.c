/* Task 3.3 (build-heap O(n) vs n inserts), 3.4 (fairness) and the sorted-list alternative */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
static long swaps;
static void sift_down(int *a, int n, int i) {
    for (;;) {
        int l = 2*i+1, r = l+1, s = i;
        if (l < n && a[l] < a[s]) s = l;
        if (r < n && a[r] < a[s]) s = r;
        if (s == i) return;
        int t = a[i]; a[i] = a[s]; a[s] = t; swaps++;
        i = s;
    }
}
static void sift_up(int *a, int i) {
    while (i > 0 && a[(i-1)/2] > a[i]) {
        int p = (i-1)/2, t = a[i]; a[i] = a[p]; a[p] = t; swaps++;
        i = p;
    }
}

/* fairness: key = (severity, arrival number); higher severity first, smaller arrival number first */
typedef struct { int sev; long seq; int id; } P;
static P hp[64]; static int hn = 0;
static int before(P a, P b) { return a.sev > b.sev || (a.sev == b.sev && a.seq < b.seq); }
static void hpush(P x) {
    int i = hn++; hp[i] = x;
    while (i > 0 && before(hp[i], hp[(i-1)/2])) {
        P t = hp[i]; hp[i] = hp[(i-1)/2]; hp[(i-1)/2] = t;
        i = (i-1)/2;
    }
}
static P hpop(void) {
    P top = hp[0]; hp[0] = hp[--hn]; int i = 0;
    for (;;) {
        int l = 2*i+1, r = l+1, b = i;
        if (l < hn && before(hp[l], hp[b])) b = l;
        if (r < hn && before(hp[r], hp[b])) b = r;
        if (b == i) break;
        P t = hp[i]; hp[i] = hp[b]; hp[b] = t;
        i = b;
    }
    return top;
}

/* alternative: sorted linked list */
typedef struct L { int sev; struct L *next; } L;
int main(void) {
    printf("n        build-heap swaps  swaps/n   n-inserts swaps  swaps/n\n");
    for (int n = 1000; n <= 1000000; n *= 10) {
        int *a = malloc(n * sizeof *a), *b = malloc(n * sizeof *b); srand(5);
        for (int i = 0; i < n; i++) a[i] = b[i] = rand();
        swaps = 0; for (int i = n/2 - 1; i >= 0; i--) sift_down(a, n, i); long s1 = swaps;
        swaps = 0; for (int i = 1; i < n; i++) sift_up(b, i); long s2 = swaps;
        printf("%-8d %-17ld %-9.3f %-16ld %.3f\n", n, s1, (double)s1/n, s2, (double)s2/n);
        free(a); free(b);
    }
    /* fairness demo: three patients with severity 8 arrive in order 1,2,3 */
    int sev[] = {5, 8, 8, 3, 8};
    for (int i = 0; i < 5; i++) hpush((P){sev[i], i, 200 + i});
    printf("fair order (severity, arrival): ");
    while (hn) { P p = hpop(); printf("P%d(%d) ", p.id, p.sev); }
    printf("\n");
    /* heap vs sorted list: n arrivals then n treatments */
    for (int n = 5000; n <= 40000; n *= 2) {
        srand(9); int *v = malloc(n * sizeof *v); for (int i = 0; i < n; i++) v[i] = rand() % 1000000;
        clock_t t0 = clock();
        int *h = malloc(n * sizeof *h); int m = 0;
        for (int i = 0; i < n; i++) { int j = m++; h[j] = -v[i]; sift_up(h, j); }
        long sink = 0; while (m) { sink += h[0]; h[0] = h[--m]; sift_down(h, m, 0); }
        double th = (double)(clock() - t0) / CLOCKS_PER_SEC;
        t0 = clock(); L *head = NULL;
        for (int i = 0; i < n; i++) { L **p = &head; while (*p && (*p)->sev >= v[i]) p = &(*p)->next; L *x = malloc(sizeof *x); x->sev = v[i]; x->next = *p; *p = x; }
        while (head) { L *x = head; head = head->next; sink += x->sev; free(x); }
        double tl = (double)(clock() - t0) / CLOCKS_PER_SEC;
        printf("n=%-6d heap %.4f s   sorted list %.4f s   (%s)\n", n, th, tl, sink == 42 ? "?" : "ok");
        free(v); free(h);
    }
    return 0;
}

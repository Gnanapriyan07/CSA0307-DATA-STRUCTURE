# CSA03 - Data Structures - Assignment 4 (CO4)
**Designing Fast Storage and Ordering of Data**

| | |
|---|---|
| Name | Gnana Priyan G |
| Register number | 192521393 |
| Department / year | IT, II year (2025 batch) |
| Faculty | Monoj D |
| Compiler | gcc 13.3.0 (Ubuntu 24.04) |
| Compile command | `gcc -std=c11 -Wall -Wextra <file>.c -o <name>` |

Extra flags: `-g -fsanitize=address` for the "Complete the Code" programs, `-O2` for benchmarks, `-O2 -fopenmp` for `t5_parallel.c`.

## How to run
    ./run_all.sh                 # compiles and runs all programs, output goes to TaskN/outputs/
or one program, for example:

    cd Task2 && gcc -std=c11 -Wall -Wextra -g -fsanitize=address t2_complete.c -o t2_complete && ./t2_complete

## Tasks
| Folder | Programs | Result (measured on my run) |
|---|---|---|
| Task1 | `t1_hash.c` | 100,000 registrations: original hash uses 9 of 1,000 buckets, longest chain 82,167; polynomial x31 with prime M = 100,003: longest chain 7; FNV-1a 7; multiplication method 9 |
| Task2 | `t2_predict.c`, `t2_complete.c`, `t2_probes.c` | prediction `42@2(1) 17@7(1) 52@3(2) 27@8(2) 99@9(1) 62@4(3)` matched; chain lengths `0200130`; measured probes agree with the formulas |
| Task3 | `t3_predict.c`, `t3_complete.c`, `t3_extra.c` | build-heap result `1 4 2 9 8 7 6` (4 swaps); triage order `P102(9) P106(8) P104(7) P103(5) P101(3) P105(1)`; build-heap 0.74 swaps per item; sorted list 3.38 s vs heap 0.0035 s at n = 40,000 |
| Task4 | `t4_predict.c`, `t4_quick.c` | partition result `2 4 3 5 9 8 7 | pivot at 3, swaps 3`; sorted input: 49,995,000 comparisons and depth 9,999, repaired sort 552,207 and depth 8; stability demonstrated |
| Task5 | `t5_complete.c`, `t5_sort.c`, `t5_parallel.c` | merge sort `#2:120 #5:120 ...`, 15 comparisons; six sorts timed for 1,000 / 100,000 / 1,000,000 items |
| Task6 | `t6_orders.c` | hash table + indexed heap + stable merge sort; at 100,000 orders: look-up 0.028 us, assign 0.23 us, report 15 ms; array re-sort alternative 2.8 ms per assignment at 50,000 |

## Notes
* **Task 5.2 (parallel sort):** my run was on a machine with **1 CPU core**, so the speed-up was only 1.00 / 1.06 / 1.09 / 1.06 for 1 / 2 / 4 / 8 threads. Re-run `t5_parallel` on a multi-core computer and use your own numbers.
* `t5_sort.c` does not run the O(n^2) sorts for 1,000,000 items (about 10^12 steps).
* The screenshots are terminal-style images rendered from the real output of these programs; replace them with your own captures if required.
* Timings depend on the machine.
* Commit each task separately as you finish it (the commit history is checked).
* The full report (Word file) is in report/
